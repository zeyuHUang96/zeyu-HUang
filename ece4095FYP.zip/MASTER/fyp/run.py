import time
import RPi.GPIO as GPIO
import setup, phase1, phase2, phase3, communication
import global_variable as g0
import communication
import socket_test

# Find out if it is the master or the follower
# g0.IS_MASTER will equal "FOLLOWER" on the follower robot, and "MASTER" on the master robot.
# status.txt is a unique text document for each robot, this just lets the program know which robot is running.
# apart from this .txt file, all the code is identical accross both robots.

def user_inputs():
	print'user_inputs run master is running\n'

	with open('status.txt') as l_txt:
		l_status = l_txt.read()
		g0.IS_MASTER = l_status

	if g0.IS_MASTER == "MASTER":
		g0.DEBUGGER_ON = False
		g0.LOGGER_ON = False
		g0.SERIAL_ON = True
		g0.PRINT_ON = True
		g0.SOCKET_ON = True

	if g0.IS_MASTER == "FOLLOWER":
		g0.DEBUGGER_ON = False
		g0.LOGGER_ON = False
		g0.SERIAL_ON = True
		g0.PRINT_ON = True
		g0.SOCKET_ON = True

	# Print the status for each robot.
	if (g0.PRINT_ON):
		print( "Debugger Status = %d" %(g0.DEBUGGER_ON) )
		print( "Logging Status = %d" %(g0.LOGGER_ON) )
		print( "Serial Status = %d" %(g0.SERIAL_ON) )
		print( "Print Status = %d" %(g0.PRINT_ON) )
		print( "Socket Status = %d" %(g0.SOCKET_ON))
		print( "Master Status = %s" %(g0.IS_MASTER))
		print( "" )

def socket_test():
	if g0.IS_MASTER == "FOLLOWER":
		communication.send_msg("1234", 1)
		time.sleep(0.1)
		communication.send_msg("-123", 1)
		time.sleep(0.1)
		communication.send_msg("r", 2)
		time.sleep(0.1)
		communication.send_msg("end", 4)
		time.sleep(0.1)
		communication.send_msg("", 3)
		print "finished sending"
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()

	else:
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()
		print communication.recv_msg()
		print "finished receiving"
		communication.send_msg("1234", 1)
		time.sleep(0.1)
		communication.send_msg("-123", 1)
		time.sleep(0.1)
		communication.send_msg("r", 2)
		time.sleep(0.1)
		communication.send_msg("end", 4)
		time.sleep(0.1)
		communication.send_msg("", 3)


user_inputs()
setup.start()




if False:
	goal = 300
	phase2.turn_compass(goal)
	in_range = 1
	offset = 10

while False:
	in_range = 1
	communication.serial_motors(-30,30)
	time.sleep(0.2)
	while in_range == 1:
		in_range = phase2.pass_offset(offset, goal)
		time.sleep(0.2)

	in_range = 1
	communication.serial_motors(30,-30)
	time.sleep(0.2)
	while in_range == 1:
		in_range = phase2.pass_offset(-offset, goal)
		time.sleep(0.2)

	offset = offset*2
	

#socket_test()
phase1.run()
#phase2.run()
#phase3.run()
setup.end()
