import serial
import my_serial
import global_variable as g0

with open('status.txt') as l_txt:
	l_status = l_txt.read()
	g0.IS_MASTER = l_status

if g0.IS_MASTER == "MASTER":
	g0.DEBUGGER_ON = False
	g0.LOGGER_ON = False
	g0.SERIAL_ON = True
	g0.PRINT_ON = True
	g0.SOCKET_ON = False

if g0.IS_MASTER == "FOLLOWER":
	g0.DEBUGGER_ON = False
	g0.LOGGER_ON = False
	g0.SERIAL_ON = True
	g0.PRINT_ON = True
	g0.SOCKET_ON = False


g0.ser = serial.Serial(
	    port='/dev/ttyACM0',
	    baudrate = 57600,
	    parity=serial.PARITY_NONE,
	    stopbits=serial.STOPBITS_ONE,
	    bytesize=serial.EIGHTBITS,
	    timeout=1)

my_serial.motors(90,-90)