import mag3110_follower
print'cal_master.py master is running\n'

compass = mag3110_follower.compass()
compass.calibrate()
