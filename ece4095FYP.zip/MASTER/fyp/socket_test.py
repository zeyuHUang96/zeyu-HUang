import global_variable as g0
import communication

def connection_test():
	msg_in = 12345
	msg = str(msg_in)
	msg_len = len(msg)
	if g0.IS_MASTER == "FOLLOWER":
		#communication.send_msg1(msg, msg_len)
		communication.send_msg(msg)
	else:
		#got = communication.recv_msg1(msg_len)
		got = communication.recv_msg()
		print got
