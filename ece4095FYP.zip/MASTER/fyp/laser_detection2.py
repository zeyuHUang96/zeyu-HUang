#===================================================================================
#   FUNCTION LIST:
#
#       PID()   - applies a PID to the error angles, to determine the wheel speed
#               - formats the wheel speed into a 9 byte global variable to send to the PSOC
#
#       capture()   - captures g1.image and rotates + filters etc.
#                   - determines the number of g1.dots detected
#                   - determines the error angles if there are two g1.dots present
#
#       draw_lines()    - if needed, prints out the data to the terminal
#                       - if needed, displays the cv g1.image
#
#
#       laser_detect()  - main function that applies all the other functions.
#                       - called from s_run.py
#
#===================================================================================

#===================================================================================
# import the necessary packages
#===================================================================================

from scipy.spatial import distance as dist
from picamera.array import PiRGBArray
from picamera import PiCamera
from imutils import perspective
from imutils import contours
import io
import time
import cv2
import imutils
import numpy as np
import math
import serial
import os
import getopt
import sys
from socket import *
from socket import error as socket_error
from multiprocessing import Pool

import global_variable as g0
import laser_globals as g1
import communication

#===================================================================================
#   variables for laser_detction.py
#===================================================================================


#===================================================================================
#   functions
#
#   PID:    input error, error_sum, error_prev
#           output motorspeed differential
#
#
#===================================================================================


def PID(error, error_sum, error_prev):
    print"PID laser_detetion2 master is running\n"

    g1.e_angle_sum = g1.e_angle_sum + g1.e_angle
    g1.motorspeed = g1.Kp * (g1.e_angle) + g1.Kd * (g1.e_angle-g1.e_angle_prev) + g1.Ki * (g1.e_angle_sum)
    g1.e_angle_sum = g1.e_angle_sum + g1.e_angle
    g1.e_angle_prev = g1.e_angle

    g1.rightMotorSpeed = 300 - g1.motorspeed
    g1.leftMotorSpeed = 300 + g1.motorspeed 
    if (g1.rightMotorSpeed > 500):
        g1.rightMotorSpeed = 500
    elif (g1.rightMotorSpeed < 100):
        g1.rightMotorSpeed = 100
    if (g1.leftMotorSpeed > 500):
        g1.leftMotorSpeed = 500
    elif (g1.leftMotorSpeed < 100):
        g1.leftMotorSpeed = 100

    l_left = int(g1.leftMotorSpeed)
    l_right= int(g1.rightMotorSpeed)
    l_direction_right = "f"
    l_direction_left = "f"

    if (g0.SERIAL_ON):
        communication.psoc_motors(l_direction, l_left, l_directoin_right, l_right)


def capture_frame(camera, rawCapture):
    return

def capture(l_frame):
    print"capture laser_detetion2 master is running\n"


    l_success1=0
    g1.image = l_frame.array
    l_rotmatrix = cv2.getRotationMatrix2D((640,0),-0.2,1)
    g1.image = cv2.warpAffine(g1.image, l_rotmatrix,(640,480))

    l_b, l_g, l_r = cv2.split(g1.image)

    l_max_intensity = np.amax(l_r)
    l_min_intensity = np.amin(l_r)
    l_thresh_value, g1.thresh = cv2.threshold(l_r,l_max_intensity-(l_max_intensity-l_min_intensity)/2, 255, cv2.THRESH_BINARY)
    l_cnts = cv2.findContours(g1.thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    l_cnts = l_cnts[0]

    g1.dots = 0
    # l_cnts should run for every dot detected
    # will highlight where the g1.dots are


    for g1.c in l_cnts:   
        if cv2.contourArea(g1.c) > 25:
                l_cArea = cv2.contourArea(g1.c)
                g1.dots = g1.dots + 1
        else:
            continue
                
        l_box = cv2.minAreaRect(g1.c)
        l_box = cv2.cv.BoxPoints(l_box) if imutils.is_cv2() else cv2.boxPoints(l_box)
        l_box = np.array(l_box, dtype="int")
        l_box = perspective.order_points(l_box)

        l_max_x = int(max(l_box[0][0],l_box[1][0],l_box[2][0],l_box[3][0]) + 10)
        if l_max_x > 640:
            l_max_x = 640
        l_min_x = int(min(l_box[0][0],l_box[1][0],l_box[2][0],l_box[3][0]) - 10)
        if l_min_x < 0:
            l_min_x = 0
        l_max_y = int(max(l_box[0][1],l_box[1][1],l_box[2][1],l_box[3][1]) + 10)
        if l_max_y > 480:
            l_max_y = 480
        l_min_y = int(min(l_box[0][1],l_box[1][1],l_box[2][1],l_box[3][1]) - 10)
        if l_min_y < 0:
            l_min_y = 0
            
        l_box_vals = g1.thresh[l_min_y:l_max_y,l_min_x:l_max_x]

        # Calculate the x centroid
        l_sum_x = l_box_vals.sum(axis=0);
        l_x_vals = np.arange(len(l_sum_x))
        l_xi = l_sum_x*l_x_vals
        l_sum_xi = np.sum(l_xi)
        l_sum_i = np.sum(l_sum_x)
        l_rel_centroid_x = l_sum_xi/l_sum_i
        l_xcoords = range(l_min_x,l_max_x+1)
        l_centroid_x = l_xcoords[l_rel_centroid_x]
        #l_xcoords = range(int(l_min_x),int(l_max_x)+1)
        #l_centroid_x = l_xcoords[int(l_rel_centroid_x)]

        # Calculate the y centroid
        l_sum_y = l_box_vals.sum(axis=1);
        l_y_vals = np.arange(len(l_sum_y))
        l_yi = l_sum_y*l_y_vals #y*i
        l_sum_yi = np.sum(l_yi)
        l_rel_centroid_y = l_sum_yi/l_sum_i
        l_ycoords = range(l_min_y,l_max_y+1)
        l_centroid_y = l_ycoords[l_rel_centroid_y]
        #l_ycoords = range(int(l_min_y),int(l_max_y)+1)
        #l_centroid_y = l_ycoords[int(l_rel_centroid_y)]


        if g1.dots<3:
            g1.laserdot[g1.dots-1][0] = l_centroid_x
            g1.laserdot[g1.dots-1][1] = l_centroid_y
        cv2.drawContours(g1.image, [l_box.astype("int")], -1, (0, 255, 0), 2)
        cv2.circle(g1.image, (l_centroid_x, l_centroid_y), 4, (255, 0, 0), -1)

    #OUT OF CNTLOOP
    if g1.dots == 2:
        if(g1.dots_prev!=2):
            print("Two g1.dots successfully found")
        if g1.laserdot[0][0] < g1.laserdot[1][0]:
            g1.frontdot[0] = g1.laserdot[0][0]
            g1.frontdot[1] = g1.laserdot[0][1]
            g1.backdot[0] = g1.laserdot[1][0]
            g1.backdot[1] = g1.laserdot[1][1]
        else:
            g1.frontdot[0] = g1.laserdot[1][0]
            g1.frontdot[1] = g1.laserdot[1][1]
            g1.backdot[0] = g1.laserdot[0][0]
            g1.backdot[1] = g1.laserdot[0][1]
        if (g0.DEBUGGER_ON):
            cv2.putText(g1.image, "front dot", (g1.frontdot[0], g1.frontdot[1]),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
            cv2.putText(g1.image, "back dot", (g1.backdot[0],g1.backdot[1]),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
            print("g1.frontdot:"+ str(g1.frontdot))
            print("g1.backdot:"+ str(g1.backdot))
        # Convert the y coordinates to a coordinate system where the centre line is zero
        g1.frontdot[1] = g1.frontdot[1] - g1.yzero
        g1.backdot[1] = g1.backdot[1] - g1.yzero

        # Convert the x coordinates to a coordinate system where no-man's land is zero
        g1.frontdot[0] = g1.frontdot[0] - g1.xzero
        g1.backdot[0] = g1.backdot[0] - g1.xzero
        
            
        if (g1.frontdot[0] > 0) or (g1.backdot[0] < 0):
            if(g1.dots_prev!=2):
                print("Interference, g1.dots found in the same sector")
              
        else:
            # If valid g1.dots have been found, set valid g1.dots to tru
            g1.validdots = True
            
            # Find the differences in x and y directions for each dot
            g1.xdiff = g1.backdot[0] - g1.frontdot[0]
            g1.ydiff = g1.backdot[1] - g1.frontdot[1]

            # Calculate the current l_angle to the laser line
            #g1.c_angle = math.degree(math.atan(g1.ydiff/g1.xdiff))
            l_angle = float(float(g1.ydiff) / float(g1.xdiff))
            if (g1.ydiff < 0):
                g1.c_angle = float(-math.degrees(math.atan(l_angle)))
            else:
                g1.c_angle = float(math.degrees(math.atan(l_angle)))
            #g1.c_angle = math.degrees(math.acos(g1.xdiff/math.sqrt((g1.xdiff**2) + (g1.ydiff**2))))
  
            # Calculate the orthogonal distance to the laser line from the axle
            # Calculate the gradient between the lines
            g1.c = g1.backdot[1] - l_angle*g1.backdot[0] # Calculate the offset of the lines from the centreline
            g1.orth_dist = l_angle*(g1.axle_pos) + g1.c
            #g1.orth_dist = round(g1.orth_dist)
            
            #print (g1.orth_dist)
            l_angle2 = float(float(-g1.orth_dist) / float(g1.dr))
            g1.t_angle = float(math.degrees(math.atan(l_angle2)))

            if g1.ydiff > 0:
                g1.c_angle = -1*g1.c_angle #l_Angle is negative if yf<yb

            
            g1.e_angle = g1.t_angle - g1.c_angle

            l_success1 = 1

    else:
        if (g0.SERIAL_ON):
            g0.ser.write("2")
        #np.append(log, "reset")
        if (g0.LOGGER_ON):
            g0.file.write("reset\n")
        if (g0.PRINT_ON):
            print("didn't find 2 dots")
        l_success1 = 0             

    if (g0.DEBUGGER_ON):
        cv2.circle(g1.image, (int(g1.xzero + g1.axle_pos), int(g1.yzero + g1.orth_dist)), 4, (255, 255, 0), -1)
        cv2.drawContours(g1.image, [axle_line.astype("int")], -1, (0, 255, 0), 1)
        cv2.drawContours(g1.image, [centre_line_x.astype("int")], -1, (0, 255, 255), 1)
        cv2.drawContours(g1.image, [centre_line_y.astype("int")], -1, (0, 255, 255), 1)
        cv2.putText(g1.image, "(x) ->", (g1.xzero+3,g1.yzero-3),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
        cv2.putText(g1.image, "(y)\/", (g1.xzero+3,g1.yzero+15),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
        cv2.imshow("Thresh", g1.thresh)
        cv2.imshow("Frame", g1.image)

    if (g0.PRINT_ON):
        g0.end = time.time()
        print("xdiff:" +str(g1.xdiff)+ "   ydiff:" +str(g1.ydiff)+ "   m:"+ str(g1.m) )
        print ("Orthogonal distance (pixels): %d"%g1.orth_dist)
        print ("Current l_angle: %3f"%(g1.c_angle))
        print ("Target l_angle: %4f"%(g1.t_angle))
        print ("Error l_angle: %5f"%(g1.e_angle))
        print("Time taken: "+ str(g0.end - g0.start))
        print("sent to PSOC: %s"%g1.val)
        print("")

    g1.dots_prev = g1.dots
    
    return l_success1
 

def start_camera():
    print"start_camera laser_detetion2 master is running\n"

    try:
        camera = PiCamera()
        camera.resolution = (640, 480)
        
        camera.framerate = 90
        
        camera.exposure_mode = "off"
        camera.awb_mode = "off"
        camera.awb_gains = [0.9,0]
        camera.brightness = 50
        camera.saturation = 100
        camera.contrast = 0
        
        rawCapture = PiRGBArray(camera, size=(640, 480))

        if (g0.PRINT_ON):
            print("Camera initialised for laser detection")
        time.sleep(0.1)
    except:
        if (g0.PRINT_ON):
            print("Error: could not initialise camera for laser detection")

    return camera, rawCapture

def initiate_laser_globals():
    
    g1.Kp = 20
    g1.Kd = 10
    g1.Ki = 0    


def laser_detect():
    print"laser_detect laser_detetion2 master is running\n"

    
    initiate_laser_globals()
    #camera, rawCapture = start_camera()

    l_success = 0

    if (g0.LOGGER_ON):
        g0.file.write("\n"+str(g1.Kp)+" | "+str(g1.Kd)+" | "+str(g1.Kd)+"\n")

    if (g0.PRINT_ON):
        g0.start = time.time()

    with PiCamera() as camera:

        camera.resolution = (640, 480)
        camera.framerate = 30
        camera.exposure_mode = "off"
        camera.awb_mode = "off"
        camera.awb_gains = [0.9,0]
        camera.brightness = 50
        camera.saturation = 100
        camera.contrast = 0

        stream = io.BytesIO()

        while (True): #create the condition to stop laser capturing 
            camera.capture(stream, format="jpeg", use_video_port=True)
            frame = np.fromstring(stream.getvalue(), dtype=np.uint8)
            stream.seek(0)
            frame = cv2.imdecode(frame, 1)




            if (l_success):
                PID()

            if (g0.PRINT_ON):
                g0.end =  time.time()
                print("time: %f"%(g0.end - g0.start))
                g0.start = g0.end


            # don't get rid of any of this stuff
            l_key = cv2.waitKey(1) & 0xFF
            if l_key == ord("q"):
               break
            #g1.rawCapture.truncate(0)
        
    #np.savetxt("data.csv", log, delimiter=",")
    if (g0.SERIAL_ON):
        g0.ser.write("2")

    if (g0.PRINT_ON):
        print("end of the run")

    time.sleep(5)
    g1.camera.close
