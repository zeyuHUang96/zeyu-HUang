import mag3110

print'com.py master is running\n'

compass = mag3110.compass()
compass.loadCalibration()
while True:
  print compass.getBearing()
