import time

import global_variable as g0
import my_socket


def motors(left_i, right_i):
	print'motors my_serial master is running\n'

	if g0.SERIAL_ON:
		if g0.IS_MASTER == "FOLLOWER":
			temp = right_i
			right_i = -left_i
			left_i = temp

		left = abs(left_i)
		right = abs(right_i)

		tempx = len(str(left))
		tempy = len(str(right))

		if (left_i > 0):
			if tempx==1:
				valx="000"+str(left)
			elif tempx==2:
				valx="00"+str(left)
			elif tempx==3:
				valx="0"+str(left)
		else:
			if tempx==1:
				valx="100"+str(left)
			elif tempx==2:
				valx="10"+str(left)
			elif tempx==3:
				valx="1"+str(left)

		if (right_i > 0):
			if tempy==1:
				valy="000"+str(right)
			elif tempy==2:
				valy="00"+str(right)
			elif tempy==3:
				valy="0"+str(right)
		else:
			if tempy==1:
				valy="100"+str(right)
			elif tempy==2:
				valy="10"+str(right)
			elif tempy==3:
				valy="1"+str(right)

		val = "1" + valx + valy
		if (g0.SERIAL_ON):
			g0.ser.write(val)


def LED(toggle, colour):
	print'LED my_serial master is running\n'

	if (colour == "red"):
		if (toggle == 1):
		    	if (g0.SERIAL_ON):
        			g0.ser.write("6")
        	elif (toggle == 0):
        		if (g0.SERIAL_ON):
        			g0.ser.write("8")

	if (colour == "blue"):
		if (toggle == 1):
		    	if (g0.SERIAL_ON):
        			g0.ser.write("7")
        	elif (toggle == 0):
        		if (g0.SERIAL_ON):
        			g0.ser.write("9")


def camera(input):
	print'camera my_serial master is running\n'

	if (g0.SERIAL_ON):
		if (input == "UP"):
			g0.ser.write("4")
		elif (input == "DOWN"):
			g0.ser.write("5")
		time.sleep(0.5)
	else:
		print("ERROR: serial not turned on. Cannot raise/lower the camera")


def colour(msg):
	print'colour my_serial master is running\n'

	# for the follower the msg is the colour to send
	# for the master the input isn't used
	if msg == "r":
		time.sleep(0.1)
		LED(0, "blue")
		time.sleep(0.1)
		LED(1, "red")
		time.sleep(0.5)
	elif msg == "b":
		time.sleep(0.1)
		LED(0, "red")
		time.sleep(0.1)
		LED(1, "blue")
		time.sleep(0.5)
	elif msg == "e":
		time.sleep(0.1)
		LED(0, "red")
		time.sleep(0.1)
		LED(0, "blue")
		time.sleep(0.5)
	elif msg == "end":
		time.sleep(0.1)
		LED(0, "red")
		time.sleep(0.1)
		LED(0, "blue")
		time.sleep(0.5)
	my_socket.sync("colour change")


def compass():

    offset = -70

    if g0.IS_MASTER == "MASTER":
        direction = g0.compass.getBearing() + offset
        if direction < 0:
            direction = direction + 360
        if direction > 360:
            direction = direction - 360

    else:
        direction = float(g0.compass.getBearing())

    return direction


def reset():
	print'reset my_serial master is running\n'

	if(g0.SERIAL_ON):
		g0.ser.write("2")
		time.sleep(1)
		if (g0.PRINT_ON):
			print("PSOC has been reset")

