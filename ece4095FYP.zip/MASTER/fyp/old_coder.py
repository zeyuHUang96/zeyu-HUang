
def capture(l_frame):
    cv2.setUseOptimized(True)
        
    ## start of main processing
    img = l_frame.array
    cv2.imwrite("cam.jpg",img)

    img = cv2.resize(img, (340, 220))#resizing image for faster processing
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)#convert to hsv format

    mask = cv2.inRange(imgHSV, g2.lowerBound, g2.upperBound)
    
    kernelOpen = np.ones((1,1))
    kernelClose = np.ones((20,20))
    
    maskOpen = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernelOpen)
    maskClose = cv2.morphologyEx(maskOpen, cv2.MORPH_CLOSE, kernelClose)

    maskFinal=maskClose
    conts, h=cv2.findContours(maskFinal.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    
    cv2.drawContours(img,conts,-1,(255,0,0),3)
    
    for i in range(len(conts)):
        x,y,w,h=cv2.boundingRect(conts[i])
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255), 2)
        #cv2.PutText(cv2.fromarray(img), str(i+1),(x,y+h), g2.font,(0,255,255))
    if (g0.DEBUGGER_ON):    
        cv2.imshow("maskClose",maskClose)
        cv2.imshow("maskOpen",maskOpen)
        cv2.imshow("mask",mask)
        cv2.imshow("cam",img)
    cv2.waitKey(10)

    if (g0.PRINT_ON):
        g0.end = time.time()
        print("Time taken: "+ str(g0.end - g0.start))
        g0.start = g0.end