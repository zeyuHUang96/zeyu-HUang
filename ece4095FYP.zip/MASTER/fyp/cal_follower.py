import mag3110_follower

print'cal_follower.py master is running \n'

compass = mag3110_follower.compass()
compass.calibrate()
