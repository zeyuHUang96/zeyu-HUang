import time
import socket

import global_variable as g0


def send_msg(msg, msg_type):
	print"send_msg master communication.py is running\n"


	if isinstance(msg, (int, long, float)):
		raise RuntimeError("message must be sent as string")

	if g0.IS_MASTER == "FOLLOWER":
	# follower to master
		# types of messages:
		# type 0: sync message
		# type 1: change wheel speed
		# type 2: change light
		# type 3: request compass value
		# type 4: stop communication wait
		size_type = [5, 8, 1, 0, 3]
	else:
		# type 0: sync message
		# type 1: send compass reading
		size_type = [5, 8]
	msg_len = size_type[msg_type]
	if len(msg) != msg_len:
		raise RuntimeError("message size and message type do not match")

	# first send the type of message.
	if g0.IS_MASTER == "FOLLOWER":
		sent = g0.client.send(str(msg_type))
	else:
		sent = g0.sock.send(str(msg_type))
	if sent == 0:
		raise RuntimeError("socket connection broken")

	# wait for recv to make sure the correct message type was received
	if g0.IS_MASTER == "FOLLOWER":
		got = g0.client.recv(1)
	else:
		got = g0.sock.recv(1)
	if got != str(msg_type):
		raise RuntimeError("recieved incorrect type back")

	totalsent = 0
	# send the rest of the message
	while totalsent < msg_len:
		if g0.IS_MASTER == "FOLLOWER":
			sent = g0.client.send(msg[totalsent:])
		else:
			sent = g0.sock.send(msg[totalsent:])
		if sent == 0:
			raise RuntimeError("socket connection broken")
		totalsent = totalsent + sent


def recv_msg():
	print"recv_msg master communication.py is running\n"

	
	chunks = []
	bytes_recd = 0



	if g0.IS_MASTER == "FOLLOWER":
		msg_type = g0.client.recv(1)
		sent = g0.client.send(msg_type)
	else:
		msg_type = g0.sock.recv(1)
		sent = g0.sock.send(msg_type)
	if sent == 0:
		raise RuntimeError("socket connection broken")

	# use the type of message to work out the size of the message
	if g0.IS_MASTER == "FOLLOWER":
		size_type = [5, 8, 1, 0, 3]
	else:
		size_type = [5, 8, 1, 0, 3]

	msg_len = size_type[int(msg_type)]
	# receive the rest of the message (message will come in multiple parts if the size of the message is greater than 2048)
	while bytes_recd < msg_len:
		if g0.IS_MASTER == "FOLLOWER":
			chunk = g0.client.recv(min(msg_len - bytes_recd, 2048))
		else:
			chunk = g0.sock.recv(min(msg_len - bytes_recd, 2048))
		if chunk == '':
			raise RuntimeError("socket connection broken")
		chunks.append(chunk)
		bytes_recd = bytes_recd + len(chunk)

	return ''.join(chunks), msg_type


def sync(msg):
	print"sync master communication.py is running\n"


	if len(msg) < 5:
		raise RuntimeError("sync message size has to be greater than 5")
	msg = msg[:5]

	if (g0.SOCKET_ON):
		if (g0.IS_MASTER == "MASTER"):
			send_msg(msg, 0)
			got, type = recv_msg()

		elif (g0.IS_MASTER == "FOLLOWER"):
			got, type = recv_msg()
			send_msg(msg, 0)

		if got == msg:
			print "Raspberry Pis synced with message: "+str(msg)
		else:
			print "recieved:               "+str(got)
			print "should ahave recieved:  "+str(msg)
			raise RuntimeError("failed to recieve identical sync messages")
	else:
		if g0.PRINT_ON:
			print "Socket turned off... at: "+str(msg)

# FOLLOWER
def setup_client():

	#try:
		g0.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		g0.sock.bind((g0.client_host, g0.port))
		g0.sock.listen(5)
		g0.client, address = g0.sock.accept()
		socket.sync("setup socket")
		g0.socket_setup = True
		if g0.PRINT_ON:
			print("socket successfully setup as client")
	#except:
		#raise RuntimeError("socket connection broken")

# MASTER
def setup_server():

	#try:
		g0.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		g0.sock.connect((g0.follower_host, g0.port))
		#g0.sock.sendall("something")
		sync("setup socket")
		g0.socket_setup = True
		if g0.PRINT_ON:
			print("socket successfully setup as server")
	#except:
		#raise RuntimeError("socket connection broken")

# writes speed and direction to motor wheels
def serial_motors(left_i, right_i):
	print"serial_motors master communication.py is running\n"

	if g0.SERIAL_ON:
		if g0.IS_MASTER == "FOLLOWER":
			temp = right_i
			right_i = -left_i
			left_i = temp

		left = abs(left_i)
		right = abs(right_i)

		tempx = len(str(left))
		tempy = len(str(right))

		if (left_i > 0):
			if tempx==1:
				valx="000"+str(left)
			elif tempx==2:
				valx="00"+str(left)
			elif tempx==3:
				valx="0"+str(left)
		else:
			if tempx==1:
				valx="100"+str(left)
			elif tempx==2:
				valx="10"+str(left)
			elif tempx==3:
				valx="1"+str(left)

		if (right_i > 0):
			if tempy==1:
				valy="000"+str(right)
			elif tempy==2:
				valy="00"+str(right)
			elif tempy==3:
				valy="0"+str(right)
		else:
			if tempy==1:
				valy="100"+str(right)
			elif tempy==2:
				valy="10"+str(right)
			elif tempy==3:
				valy="1"+str(right)

		val = "1" + valx + valy
		print val
		if (g0.SERIAL_ON):
			g0.ser.write(val)


def LED(toggle, colour):
	print"LED master communication.py is running\n"

	if (colour == "red"):
		if (toggle == 1):
		    	if (g0.SERIAL_ON):
        			g0.ser.write("6")
        	elif (toggle == 0):
        		if (g0.SERIAL_ON):
        			g0.ser.write("8")

	if (colour == "blue"):
		if (toggle == 1):
		    	if (g0.SERIAL_ON):
        			g0.ser.write("7")
        	elif (toggle == 0):
        		if (g0.SERIAL_ON):
        			g0.ser.write("9")


def camera(input):
	print"camera master communication.py is running\n"

	if (g0.SERIAL_ON):
		if (input == "UP"):
			g0.ser.write("4")
		elif (input == "DOWN"):
			g0.ser.write("5")
		time.sleep(0.5)
	else:
		print("ERROR: serial not turned on. Cannot raise/lower the camera")


def reset():
	print"reset master communication.py is running\n"

	if(g0.SERIAL_ON):
		g0.ser.write("2")
		time.sleep(1)
		if (g0.PRINT_ON):
			print("PSOC has been reset")
	

def colour(msg):
	print"colour master communication.py is running\n"

	# for the follower the msg is the colour to send
	# for the master the input isn't used

	if g0.SOCKET_ON:
		sync("START OF COLOUR CHANGE")
		if (g0.IS_MASTER == "FOLLOWER"):
			send_msg(msg, 2)
				
		elif(g0.IS_MASTER == "MASTER"):
			msg, type_msg = recv_msg()
			if msg == "r":
				time.sleep(0.1)
				LED(0, "blue")
				time.sleep(0.1)
				LED(1, "red")
				time.sleep(0.5)
			elif msg == "b":
				time.sleep(0.1)
				LED(0, "red")
				time.sleep(0.1)
				LED(1, "blue")
				time.sleep(0.5)
			elif msg == "end":
				time.sleep(0.1)
				LED(0, "red")
				time.sleep(0.1)
				LED(0, "blue")
				time.sleep(0.5)

		sync("END OF COLOUR CHANGE")
		return msg


def socket_motors(msg):
	print"socket_motors master communication.py is running\n"

	# for the follower the msg is the speed to the left motor
	# the speed of the right motor will be the opposite
	# for the master the message isn't used
	
	sync("START OF MOTOR CHANGE")			

	if (g0.IS_MASTER == "FOLLOWER"):
		if msg != "end":
			send_msg(msg, 1)
		else:
			send_msg(msg, 4)
			
	elif(g0.IS_MASTER == "MASTER"):
		msg, msg_type = recv_msg()

		if msg == "end":
			serial_motors(0,0)
		else:
			serial_motors(int(msg), -int(msg))

	sync("END OF MOTOR CHANGE")
	return msg


def send_compass():
	print"send_compass master communication.py is running\n"

	reading = string(g0.compass.getBearing())
	send_msg(reading[:7], 1)

def recv_compass():
	print"recv_compass master communication.py is running\n"

	send_msg("", 3)
	msg, msg_type = recv_msg()
	msg = float(msg)
	return msg


def wait_for_messages():
	print"wait_for_messages master communication.py is running\n"

	msg_type = 0
	while msg_type != 4:
		msg, msg_type = recv_msg()
		if msg_type == 1:
			my_serial.motors(int(msg[:4]), int(msg[5:]))
		if msg_type == 2:
			my_serial.colour(msg)
		if msg_type == 3:
			my_socket.compass()
	serial_motors(0,0)
	colour("end")
