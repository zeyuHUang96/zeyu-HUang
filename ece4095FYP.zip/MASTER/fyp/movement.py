import communication
import time
import global_variable as g0

def spin(speed, direction):

	if (direction == "left"):
		communication.serial_motors(-speed, speed)
	else:
		communication.serial_motors(speed, -speed)	

