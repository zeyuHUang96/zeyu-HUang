import time
import socket

import my_serial
import global_variable as g0

# ===================================================
# function list:
# send_msg - sends a message to the other raspberry pi
# recv_msg - recieves a message from the other raspberry pi
# sync - uses send_msg and recv_msg to make sure programs are running simultaneously
# send_compass - reads compass and sends value
# recv_compass - send request and receives compass values



def send_msg(msg, msg_type):
	print "send_msg my_socket is running\n"


	if isinstance(msg, (int, long, float)):
		raise RuntimeError("message must be sent as string")

	if g0.IS_MASTER == "FOLLOWER":
	# follower to master
		# types of messages:
		# type 0: sync message
		# type 1: change wheel speed
		# type 2: change light
		# type 3: request compass value
		# type 4: stop communication wait
		size_type = [5, 8, 1, 0, 3]
	else:
		# type 0: sync message
		# type 1: send compass reading
		size_type = [5, 8]
	msg_len = size_type[msg_type]
	if len(msg) != msg_len:
		print "message length: "+str(len(msg))
		print "desired length: "+str(msg_len)
		raise RuntimeError("message size and message type do not match")

	# first send the type of message.
	if g0.IS_MASTER == "FOLLOWER":
		sent = g0.client.send(str(msg_type))
	else:
		sent = g0.sock.send(str(msg_type))
	if sent == 0:
		raise RuntimeError("socket connection broken")

	# wait for recv to make sure the correct message type was received
	if g0.IS_MASTER == "FOLLOWER":
		got = g0.client.recv(1)
	else:
		got = g0.sock.recv(1)
	if got != str(msg_type):
		raise RuntimeError("recieved incorrect type back")

	totalsent = 0
	# send the rest of the message
	while totalsent < msg_len:
		if g0.IS_MASTER == "FOLLOWER":
			sent = g0.client.send(msg[totalsent:])
		else:
			sent = g0.sock.send(msg[totalsent:])
		if sent == 0:
			raise RuntimeError("socket connection broken")
		totalsent = totalsent + sent


def recv_msg():
	print "recv_msg my_socket is running\n"

	
	chunks = []
	bytes_recd = 0

	if g0.IS_MASTER == "FOLLOWER":
		msg_type = g0.client.recv(1)
		sent = g0.client.send(msg_type)
	else:
		msg_type = g0.sock.recv(1)
		sent = g0.sock.send(msg_type)
	if sent == 0:
		raise RuntimeError("socket connection broken")

	# use the type of message to work out the size of the message
	if g0.IS_MASTER == "FOLLOWER":
		size_type = [5, 8]
	else:
		size_type = [5, 8, 1, 0, 3]

	msg_len = size_type[int(msg_type)]
	# receive the rest of the message (message will come in multiple parts if the size of the message is greater than 2048)
	while bytes_recd < msg_len:
		if g0.IS_MASTER == "FOLLOWER":
			chunk = g0.client.recv(min(msg_len - bytes_recd, 2048))
		else:
			chunk = g0.sock.recv(min(msg_len - bytes_recd, 2048))
		if chunk == '':
			raise RuntimeError("socket connection broken")
		chunks.append(chunk)
		bytes_recd = bytes_recd + len(chunk)

	return ''.join(chunks), msg_type


def sync(msg):
	print "sync my_socket is running\n"


	initial_msg = msg

	if len(msg) < 5:
		raise RuntimeError("sync message size has to be greater than 5")
	msg = msg[:5]

	if (g0.SOCKET_ON):
		if (g0.IS_MASTER == "MASTER"):
			send_msg(msg, 0)
			got, type = recv_msg()

		elif (g0.IS_MASTER == "FOLLOWER"):
			got, type = recv_msg()
			send_msg(msg, 0)

		if got == msg:
			print "Raspberry Pis synced with message: "+str(initial_msg)
		else:
			print "recieved:               "+str(got)
			print "should ahave recieved:  "+str(msg)
			raise RuntimeError("failed to recieve identical sync messages")
	else:
		if g0.PRINT_ON:
			print "Socket turned off... at: "+str(initial_msg)


def send_compass():
	print "send_compass my_socket is running\n"

	reading = str(my_serial.compass())
	while len(reading)<8:
		reading = "0"+reading
	send_msg(reading[:8], 1)


def recv_compass():
	print "recv_compass my_socket is running\n"

	send_msg("", 3)
	msg, msg_type = recv_msg()
	msg = float(msg)
	return msg


def wait_for_messages():
	print "wait_for_messages my_socket is running\n"

	msg_type = 0
	while msg_type != "4":
		print "in loop"
		msg, msg_type = recv_msg()
		if msg_type == "1":
			print "change motor request"
			my_serial.motors(int(msg[:4]), int(msg[4:]))
			sync("change speed")
		if msg_type == "2":
			print "change colour request"
			my_serial.colour(msg)
		if msg_type == "3":
			print "send compass request"
			send_compass()
	my_serial.motors(0,0)
