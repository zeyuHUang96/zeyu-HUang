
import cv2 as cv
import numpy as np
 
 
def blur_demo(image):
    dst = cv.blur(image, (15, 1))
    cv.imshow("blur_demo", dst)
 
src = cv.imread("mapping_area'.jpg")

cv.namedWindow("input image", cv.WINDOW_AUTOSIZE)
cv.imshow("input image", src)
blur_demo(src)
cv.waitKey(0)
cv.destroyAllWindows()
