import serial, os, getopt, sys, socket, communication, time, random
import mag3110_master, mag3110_follower
from socket import error as socket_error

#from functions import PID, capture, write_data, draw_lines, send_result
import global_variable as g0
import laser_globals as g1
import my_socket, my_serial

g0.IS_MASTER="FOLLOWER"


if g0.IS_MASTER == "FOLLOWER":
	g0.compass = mag3110_master.compass()
	g0.compass.loadCalibration()

else:
	g0.compass = mag3110_master.compass()
	g0.compass.loadCalibration()


while True:
		
	if g0.IS_MASTER == "FOLLOWER":
		direction = g0.compass.getBearing()
	if direction < 0:
		direction = direction #+ 360
	if direction > 360:
		direction = direction #- 360
	print direction

