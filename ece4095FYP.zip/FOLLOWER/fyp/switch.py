import RPi.GPIO as GPIO
import time
import subprocess, os
import signal
import global_variable as g0


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO_switch = 17  # pin 18
GPIO.setup(GPIO_switch, GPIO.IN, pull_up_down=GPIO.PUD_UP)

print "  Press Ctrl & C to Quit"

rpistr = "python reset.py"
subprocess.Popen(rpistr,shell=True, preexec_fn=os.setsid)

try:
	run = 0
	while True :
		if GPIO.input(GPIO_switch)==0:
			print "  Started"
			rpistr = "python run.py"
			p=subprocess.Popen(rpistr,shell=True, preexec_fn=os.setsid)
			run = 1
			while GPIO.input(GPIO_switch)==0:
				time.sleep(0.1)
		if GPIO.input(GPIO_switch)==1 and run == 1:
			run = 0
			print "  Stopped " 
			os.killpg(p.pid, signal.SIGTERM)
			rpistr = "python reset.py"
			p=subprocess.Popen(rpistr,shell=True, preexec_fn=os.setsid)
			while GPIO.input(GPIO_switch)==1:
				time.sleep(0.1)
       

except KeyboardInterrupt:
	os.killpg(p.pid, signal.SIGTERM)
	if g0.socket_setup:
		time.sleep(0.1)
		g0.sock.close()
	rpistr = "python reset.py"
	p = subprocess.Popen(rpistr,shell=True, preexec_fn=os.setsid)
  	print "  Quit"
  	GPIO.cleanup() 
