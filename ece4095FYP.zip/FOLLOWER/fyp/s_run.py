# import the necessary packages
import time

#from functions import PID, capture, write_data, draw_lines, send_result
#from laser_detection import laser_detect
from ball_detect import ball_detect, ball_detect_inf
from laser_detection import laser_detect, dot_detect
from setup import setup_master, setup_follower
import movement
import communication

# import global variables
import global_variable as g0


print "s_run.py is running"


# should we use the debugger or log data?
with open('status.txt') as l_txt:
	l_status = l_txt.read()
	g0.IS_MASTER = l_status


g0.DEBUGGER_ON = True
g0.LOGGER_ON = False
if (g0.IS_MASTER == "MASTER"):
	g0.SERIAL_ON = True
else:
	g0.SERIAL_ON = True
g0.PRINT_ON = True
g0.SOCKET_ON = True

time.sleep(0.1)
# enter main function


if (g0.PRINT_ON):
	print( "Debugger Status = %d" %(g0.DEBUGGER_ON) )
	print( "Logging Status = %d" %(g0.LOGGER_ON) )
	print( "Serial Status = %d" %(g0.SERIAL_ON) )
	print( "Print Status = %d" %(g0.PRINT_ON) )
	print( "Socket Status = %d" %(g0.SOCKET_ON))
	print( "Master Status = %s" %(g0.IS_MASTER))
	print( " " )


# MASTER IS THE CLIENT
if (g0.IS_MASTER == "MASTER"):
	setup_master()
	g0.ser.write("5")
	if (g0.SOCKET_ON):
		communication.setup_server()

	ball_detect()
	#dot_detect()
	#laser_detect()


# FOLLOWER IS THE SERVER
if (g0.IS_MASTER == "FOLLOWER"):
	setup_follower()

	if (g0.SOCKET_ON):
		communication.setup_client()

	ball_detect_inf()
	#dot_detect()
	#laser_detect()


time.sleep(0.1)
g0.sock.close()
communication.reset()
