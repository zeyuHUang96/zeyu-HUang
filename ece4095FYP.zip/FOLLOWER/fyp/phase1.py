from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
from imutils import perspective


import global_variable as g0
import laser_globals as g2
import communication, my_socket, my_serial


def PID(error):

    Kp = 0.2
    Kd = 0
    g2.error_sum = g2.error_sum + error
    motorspeed = Kp*(error) + Kd*(error - g2.error_prev)

    if (abs(motorspeed) < 7):
        if motorspeed < 0:
            motorspeed = -7
        else: 
            motorspeed = 7
    g2.error_prev = error
	
    rightMotorSpeed = 0 - motorspeed
    leftMotorSpeed = 0 + motorspeed 
    
    if (rightMotorSpeed > 15):
        rightMotorSpeed = 15
    elif (rightMotorSpeed < -15):
        rightMotorSpeed = -15
    if (leftMotorSpeed > 15):
        leftMotorSpeed = 15
    elif (leftMotorSpeed < -15):
        leftMotorSpeed = -15

    left = int(leftMotorSpeed)
    right = int(rightMotorSpeed)
    print("PID calculated speed; left: "+str(left)+"     right: "+str(right))
    if (g0.SERIAL_ON):
		my_serial.motors(left,right)
    return left


def capture( l_frame, size, colour, previous_centroid, speed,out):

    print colour
    cv2.setUseOptimized(True)
    bounding_box_hor = 200
    bounding_box_ver = 20

    if (colour == "red"):
        g2.lowerBound = np.array([0, 60, 25])
        g2.upperBound = np.array([10, 255, 255])
        lowerBound2 = np.array([160, 60, 25])
        upperBound2 = np.array([180, 255, 255])
    elif (colour == "blue"):
        g2.lowerBound = np.array([100, 100, 80])
        g2.upperBound = np.array([130, 255, 255])

    ## start of main processing
    img2 = l_frame.array
    rotmatrix = cv2.getRotationMatrix2D((size[0]/2,size[1]/2), 270, 1)
    img = cv2.warpAffine(img2, rotmatrix, size)


    if previous_centroid != "":
        g2.next_centroid[0] = previous_centroid[0] - speed
        g2.next_centroid[1] = previous_centroid[1]
        x1 = max(g2.next_centroid[0]-bounding_box_hor, 0)
        x2 = min(g2.next_centroid[0]+bounding_box_hor,size[0])
        y1 = max(g2.next_centroid[1]-bounding_box_ver, 0)
        y2 = min(g2.next_centroid[1]+bounding_box_ver, size[1])
        img = img[y1:y2, x1:x2]

    
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)#convert to hsv format
    frame_threshed = cv2.inRange(imgHSV, g2.lowerBound, g2.upperBound)

    if colour == "red":
        frame_thresheda = cv2.inRange(imgHSV, lowerBound2, upperBound2)
        frame_threshed = frame_threshed | frame_thresheda

    if False:
        g2.next_centroid[0] = previous_centroid[0] - speed
        g2.next_centroid[1] = previous_centroid[1]
        x1 = g2.next_centroid[0]-bounding_box_hor
        x2 = g2.next_centroid[0]+bounding_box_hor
        y1 = g2.next_centroid[1]-bounding_box_ver
        y2 = g2.next_centroid[1]+bounding_box_ver
        frame_threshed = frame_threshed[y1:y2, x1:x2]




    cv2.imwrite("HSV.png",frame_threshed)   
    conts = cv2.findContours(frame_threshed.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

    conts = conts[1]
    number = 0
    i = 0
    j = 0
    locations = []

    for c in conts:
        if (cv2.contourArea(c) > 10.0):
            number = number + 1
        else:
            continue

        box = cv2.minAreaRect(c)
        box = cv2.boxPoints(box)
        box = np.array(box, dtype = "int")
        box = perspective.order_points(box)

        max_x = int(max(box[0][0],box[1][0],box[2][0],box[3][0]) + 10)
        if max_x > size[1]:
            max_x = size[1]
        min_x = int(min(box[0][0],box[1][0],box[2][0],box[3][0]) - 10)
        if min_x < 0:
            min_x = 0
        max_y = int(max(box[0][1],box[1][1],box[2][1],box[3][1]) + 10)
        if max_y > size[0]:
            max_y = size[0]
        min_y = int(min(box[0][1],box[1][1],box[2][1],box[3][1]) - 10)
        if min_y < 0:
            min_y = 0

        box_vals = frame_threshed[min_y:max_y, min_x:max_x]

        # Calculate the x centroid
        sum_x = box_vals.sum(axis=0);
        x_vals = np.arange(len(sum_x))
        xi = sum_x*x_vals
        sum_xi = np.sum(xi)
        sum_i = np.sum(sum_x)
        rel_centroid_x = sum_xi/sum_i
        xcoords = range(min_x,max_x+1)
        centroid_x = xcoords[rel_centroid_x]
        if previous_centroid != "":
            centroid_x = centroid_x + g2.next_centroid[0] - bounding_box_hor
        #xcoords = range(int(min_x),int(max_x)+1)
        #centroid_x = xcoords[int(rel_centroid_x)]

        # Calculate the y centroid
        sum_y = box_vals.sum(axis=1);
        y_vals = np.arange(len(sum_y))
        yi = sum_y*y_vals #y*i
        sum_yi = np.sum(yi)
        rel_centroid_y = sum_yi/sum_i
        ycoords = range(min_y,max_y+1)
        centroid_y = ycoords[rel_centroid_y]
        if previous_centroid != "":
            centroid_y = centroid_y + g2.next_centroid[1] - bounding_box_ver
        #ycoords = range(int(min_y),int(max_y)+1)
        #centroid_y = ycoords[int(rel_centroid_y)]

        if colour == "blue":
            locations.append(min_x)
            locations.append(max_x)
            locations.append(min_y)
            locations.append(max_y)
        if colour == "red":
            locations.append(centroid_x)
            locations.append(centroid_y)

        cv2.drawContours(img,[c],-1,(0,255,0),1)
        cv2.circle(img, (centroid_x, centroid_y), 4, (255, 0, 0), 1)
        cv2.putText(img, "center", (centroid_x - 20, centroid_y - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    if previous_centroid != "":

        cv2.rectangle(img, (x1,y1),(x2,y2), (0,0,255),4)
        cv2.circle(img, (g2.next_centroid[0], g2.next_centroid[1]), 4, (255,0,0),1)
    for i in range(len(conts)):
        x,y,w,h=cv2.boundingRect(conts[i])
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255), 4)
        #cv2.PutText(cv2.fromarray(img), str(i+1),(x,y+h), g2.font,(0,255,255))
    if (g0.DEBUGGER_ON):    
        cv2.imshow("cam",img2)
        #cv2.imshow("img",img3)
        cv2.imshow("thresh",frame_threshed)
        cv2.waitKey(10)
    out.write(img)
    if (g0.PRINT_ON):
        g0.end = time.time()
        print("Time taken: "+ str(g0.end - g0.start))
        g0.start = g0.end

    if (number > 0):
        error = size[0]/2 - centroid_x
    else:
        error = 0
    error = -error

    if previous_centroid != "" and number > 0:
        centroid = [centroid_x, centroid_y]
    else:
        centroid = ""

    if colour == "red":
        cv2.imwrite("red.png",img)
    else:
        cv2.imwrite("blue.png",img)


    return error, number, locations, centroid


def start_camera(size):

    try:
        g2.camera = PiCamera()
        g2.camera.resolution = size
    
        #g2.camera.framerate = 90
        
        g2.camera.exposure_mode = "off"
        #g2.camera.awb_mode = "off"
        #g2.camera.awb_gains = [0.9,0]
        #g2.camera.brightness = 50
        #g2.camera.saturation = 100
        #g2.camera.contrast = 0
        
        g2.rawCapture = PiRGBArray(g2.camera, size)#get camera data Original citation
        print("Camera initialised for ball detection")
        time.sleep(0.1)
    except:
        print("Error: could not initialise camera for ball detection")


def close_camera():
    g2.camera.close()
    del g2.camera


def run_follower():

    size = (1088, 1088)
    colour = "blue"
    my_serial.camera("UP")
    start_camera(size)  # starts the camera
    g0.start = time.time()
    red_success = 0
    success_error = 0


    # SCENARIO 1: scenario that occurs when changing from red to blue without a successful red detection
    # SCENARIO 2: scenario that occurs when it is still searching for a blue reading
    # SCENARIO 6: it has found a blue dot, but stays stationary to get another blue reading
    # SCENARIO 3: following on from SCENARION 6, takes a red reading in the same location, and compares the two
    # SCENARIO 4: occurs immediately after a successful red reading, changes the light back to blue
    # SCENARIO 5: puts the robot into the PID loop.


    SCENARIO = 1
    my_socket.send_msg("b", 2)
    my_socket.sync("colour change")
    speed = 30
    my_serial.motors(30,-30)
    centroid = ""
    #DELETE THIS
    #fourcc=cv2.cv.CV_FOURCC(*'XVID')
    fourcc = cv2.VideoWriter_fourcc(*'XVID') 
    out=cv2.VideoWriter('phase1.avi',fourcc,5,(1088,1088))


    #
    for l_frame in g2.camera.capture_continuous(g2.rawCapture, format="bgr", use_video_port=True):
        print("\n\n")
        print "SCENARIO: "+str(SCENARIO)
        print "centroid: "+str(centroid)

        # capture either red or blue frame

        if SCENARIO == 3:
            error_red, number_red, list_red, centroid = capture(l_frame, size, "red", centroid, speed,out)
            print list_red
        elif SCENARIO == 1 or SCENARIO == 2 or SCENARIO == 4 or SCENARIO == 5 or SCENARIO == 6:
            error_blue, number_blue, list_blue, centroid = capture(l_frame, size, "blue", centroid, speed,out)
            print list_blue

        # if in SCENARIO 3, check if red dot is in same place as next
        if SCENARIO == 3:
            for j in range(0, number_blue):
                for k in range(0, number_red):
                    if (list_red[2*k] > list_blue[4*j] and list_red[2*k] < list_blue[4*j+1]) or (abs(list_red[2*k] - (list_blue[4*j]+list_blue[4*j+1])/2) < 30):
                        if (list_red[2*k+1] > list_blue[4*j+2] and list_red[2*k+1] < list_blue[4*j+3]) or (abs(list_red[2*k+1] - (list_blue[4*j+2]+list_blue[4*j+3])/2) < 30):
                            dot_x = list_red[2*k]
                            dot_y = list_red[2*k+1]
                            red_success = 1
                            centroid = [int((list_blue[4*j]+list_blue[4*j+1])/2), int((list_blue[4*j+2]+list_blue[4*j+3])/2)]
                            print centroid
                            print "SUCCESS!!!!"
            number_blue = 0
            number_red = 0

        # determine next SCENARIO
        if SCENARIO == 1:
            if number_blue == 0:
                centroid = ""
                SCENARIO = 2
            else:
                centroid = ""
                SCENARIO = 6

        elif SCENARIO == 2:
            if number_blue == 0:
                SCENARIO = 2
            else:
                SCENARIO = 6

        elif SCENARIO == 6:
            SCENARIO = 3

        elif SCENARIO == 3:
            if red_success == 1:
                SCENARIO = 4
            else:
                SCENARIO = 1

        elif SCENARIO == 4:
            SCENARIO = 5


        # setup for next run
        if SCENARIO == 1:
            speed = 90
            my_serial.motors(30,30)
            my_socket.send_msg("b", 2)
            my_socket.sync("colour change")
        elif SCENARIO == 6:
            speed = 0
            my_serial.motors(0,0)
            time.sleep(0.2)
        elif SCENARIO == 2:
            my_serial.motors(30,30)
            time.sleep(0.2)
        elif SCENARIO == 3:
            my_socket.send_msg("r", 2)
            my_socket.sync("colour change")
        elif SCENARIO == 4:
            my_socket.send_msg("b", 2)
            my_socket.sync("colour change")
        elif SCENARIO == 5:
            if abs(error_blue) < 20:
                my_serial.motors(0,0)
                time.sleep(1)
                SCENARIO = 7
            else:
                print error_blue
                speed = PID(error_blue)
        elif SCENARIO == 7:
            if abs(error_blue) < 20:
                print "finished ball_detect"
                my_socket.send_msg("e", 2)
                my_socket.sync("colour change")
                my_socket.send_msg("end", 4)
                print "final error found as: "+str(error_blue)
                break
            else:
                print error_blue
                speed = PID(error_blue)
                SCNENARIO = 5

        # don't get rid of any of this stuff
        l_key = cv2.waitKey(1) & 0xFF

        if l_key == ord("q"):
            g2.rawCapture.truncate(0)  # clear the stream in preparation for the next frame
            break

        g2.rawCapture.truncate(0)

    g2.rawCapture.truncate(0)
    close_camera()


def run_master():
    my_socket.wait_for_messages()
    print "out of waitinf for messages"

def run():
    print "phase1 is running (slave)"    
    my_socket.sync("PHASE 1 START")
    
    if (g0.IS_MASTER == "FOLLOWER"):
        run_follower()

    elif (g0.IS_MASTER == "MASTER"):
        run_master()
        
    my_socket.sync("PHASE 1 END\n\n")
                
