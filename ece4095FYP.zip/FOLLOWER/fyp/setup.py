import serial, os, getopt, sys, socket, communication, time, random
import mag3110_master, mag3110_follower
from socket import error as socket_error

#from functions import PID, capture, write_data, draw_lines, send_result
import global_variable as g0
import laser_globals as g1
import my_socket, my_serial


def setup_server():
	try:
		g0.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		g0.sock.bind((g0.client_host, g0.port))
		g0.sock.listen(5)
		g0.client, address = g0.sock.accept()
		my_socket.sync("setup socket")
		g0.socket_setup = True
		if g0.PRINT_ON:
			print("socket successfully setup as client")
	except:
		raise RuntimeError("socket connection broken")

def setup_client():
	try:
		g0.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		g0.sock.connect((g0.follower_host, g0.port))
		my_socket.sync("setup socket")
		g0.socket_setup = True
		if g0.PRINT_ON:
			print("socket successfully setup as server")
	except:
		raise RuntimeError("socket connection broken")

def set_ser():
	g0.ser = serial.Serial(
	    port='/dev/ttyACM0',
	    baudrate = 57600,
	    parity=serial.PARITY_NONE,
	    stopbits=serial.STOPBITS_ONE,
	    bytesize=serial.EIGHTBITS,
	    timeout=1)

def set_compass():
	if g0.IS_MASTER == "FOLLOWER":
		g0.compass = mag3110_follower.compass()
	else:
		g0.compass = mag3110_master.compass()
	g0.compass.loadCalibration()

def set_socket():
	if g0.IS_MASTER == "FOLLOWER":
		setup_server()
	else:
		setup_client()


def set_log():
	g0.file = open("/home/pi/github/FYP_SlavePi/data.csv","w").close()      
	g0.file = open("/home/pi/github/FYP_SlavePi/data.csv","a")


def start():
	time.sleep(0.1)
	if (g0.LOGGER_ON):
		set_log()
	if (g0.SERIAL_ON):
		set_ser()
		communication.reset()
	if (g0.SOCKET_ON):
		set_socket()
	set_compass()
	time.sleep(2)




def end():
	if g0.SOCKET_ON:
		time.sleep(0.1)
		g0.sock.close()
	if g0.SERIAL_ON:
		communication.reset()

def randomize():
	if g0.SOCKET_ON:
		x = random.randint(2,10)
		communication.serial_motors(100,-100)
		time.sleep(x)
		communication.serial_motors(0,0)
		time.sleep(0.1)
