import numpy as np
import cv2

import RPi.GPIO as GPIO
import time
import math


def sr_mapping(robot_x,robot_y,img):
	point_size = 10
	point_color = (255, 255, 255) 
	thickness = 4 
	point_x=robot_x
	point_y=robot_y-int(sr_04()*9)
	point=(point_x,point_y)
	cv2.circle(img, point, point_size, point_color, thickness)
	cv2.imwrite("mapping.jpg", img)

def sr_mapping_theta(robot_x,robot_y,img,theta,scale_index):
	scale_index=4
	robot_x =robot_x-6*scale_index#transfer to sonar pos x.
	point_size = 9
	point_color = (255, 255, 255) 
	thickness = 3 
	point_x_right=robot_x-int(7.5+sr_04_right()*math.sin(theta)*scale_index)
	point_y_right=robot_y-int(7.5+sr_04_right()*math.cos(theta)*scale_index)
	point_right=(point_x_right,point_y_right)
	cv2.circle(img, point_right, point_size, point_color, thickness)
	point2=(robot_x,robot_y)
	point_color2 = (0, 0, 255) 
	cv2.circle(img, point2, point_size, point_color2, thickness)
	
	point_x_left=robot_x+int(7.5+sr_04_left()*math.sin(theta)*scale_index)
	point_y_left=robot_y+int(7.5+sr_04_left()*math.cos(theta)*scale_index)
	point_left=(point_x_left,point_y_left)
	cv2.circle(img, point_left, point_size, point_color, thickness)

	#rectangle both Diagonal coordinates
	
	h =30
	x1=int(point_x_left-h*math.cos(theta))
	y1=int(point_y_left+h*math.sin(theta))
	x4=int(point_x_left+h*math.cos(theta))
	y4=int(point_y_left-h*math.sin(theta))
	x2=int(robot_x-h*math.cos(theta))
	y2=int(robot_y+h*math.sin(theta))
	x3=int(robot_x+h*math.cos(theta))
	y3=int(robot_y-h*math.sin(theta))
	pts = np.array([[x1,y1],[x2,y2],[x3,y3],[x4,y4]])
	cv2.fillConvexPoly(img,pts,(0,0,255))
	
	x1_r=int(point_x_right-h*math.cos(theta))
	y1_r=int(point_y_right+h*math.sin(theta))
	x4_r=int(point_x_right+h*math.cos(theta))
	y4_r=int(point_y_right-h*math.sin(theta))
	x2_r=int(robot_x-h*math.cos(theta))
	y2_r=int(robot_y+h*math.sin(theta))
	x3_r=int(robot_x+h*math.cos(theta))
	y3_r=int(robot_y-h*math.sin(theta))
	pts_r= np.array([[x1_r,y1_r],[x2_r,y2_r],[x3_r,y3_r],[x4_r,y4_r]])
	cv2.fillConvexPoly(img,pts_r,(0,255,255))
	
	cv2.circle(img, point_right, point_size, point_color, thickness)
	cv2.circle(img, point_left, point_size, point_color, thickness)
	cv2.circle(img, point2, point_size, point_color2, thickness)
	
	cv2.imwrite("mapping_area'.jpg", img)
	

def draw_car_shape(x,y,img,theta,scale_index):
	
	l1=10.6066*scale_index
	l2=14.5774*scale_index
	w1=7.5*scale_index
	theta1=math.radians(45)
	theta2=math.radians(30.9638)

	x1=int(x+l1*math.cos(theta+theta1))
	y1=int(y-l1*math.sin(theta+theta1))
	x2=int(x+l1*math.cos(theta1-theta))
	y2=int(y+l1*math.sin(theta1-theta))
	x3=int(x-l2*math.cos(theta+theta2))
	y3=int(y+l2*math.sin(theta+theta2))
	x4=int(x-l2*math.cos(theta2-theta))
	y4=int(y-l2*math.sin(theta2-theta))
	pts_r= np.array([[x1,y1],[x2,y2],[x3,y3],[x4,y4]])
	cv2.fillConvexPoly(img,pts_r,(255,255,255))
	
def draw_sr_area_left(l,x,y,img,theta,scale_index):
	l0=int(11.3936*scale_index)
	l=int(l*scale_index)
	x1=-1*int(9.3367*scale_index*math.cos(theta+math.radians(9.8271)))+x
	y1=int(9.3367*scale_index*math.sin(theta+math.radians(9.8271)))+y
	
	angle=7.6-0.2*l/200
	theta2=-1*(180/math.pi*theta+90)
	
	cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)
	#cv2.ellipse(img,(x1,y1),(l0,l0),theta2,-1*angle,angle,(0,0,0),-1)
	

def draw_sr_area_right(l,x,y,img,theta,scale_index):
	l0=int(11.3936*scale_index)
	l=int(l*scale_index)
	x1=-1*int(9.3367*scale_index*math.cos(-theta+math.radians(9.8271)))+x
	y1=-1*int(9.3367*scale_index*math.sin(-theta+math.radians(9.8271)))+y
		
	angle=7.6-0.2*l/200
	theta2=90-180/math.pi*theta#(180/math.pi*theta+90)
	
	cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)
	#cv2.ellipse(img,(x1,y1),(l0,l0),theta2,-1*angle,angle,(0,0,0),-1)

def sr_04_left():
	GPIO.setmode(GPIO.BCM)
	TRIG = 23 
	ECHO = 24
	GPIO.setup(TRIG,GPIO.OUT)
	GPIO.setup(ECHO,GPIO.IN)

	print "Distance Measurement right In Progress"	

	GPIO.output(TRIG, False)
	#print "Waiting For Sensor To Settle"
	time.sleep(0.1)

	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)

	while GPIO.input(ECHO)==0:
	  pulse_start = time.time()

	while GPIO.input(ECHO)==1:
	  pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151

	distance = round(distance, 2)
	print distance
	GPIO.cleanup()
	
	return distance
	
def sr_04_right():
	GPIO.setmode(GPIO.BCM)
	TRIG = 27 
	ECHO = 22
	GPIO.setup(TRIG,GPIO.OUT)
	GPIO.setup(ECHO,GPIO.IN)

	print "Distance Measurement left In Progress"	

	GPIO.output(TRIG, False)
	#print "Waiting For Sensor To Settle"
	time.sleep(0.1)

	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)

	while GPIO.input(ECHO)==0:
	  pulse_start = time.time()

	while GPIO.input(ECHO)==1:
	  pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151

	distance = round(distance, 2)
	print distance
	GPIO.cleanup()
	
	return distance

def sr_04_both():
	GPIO.setmode(GPIO.BCM)
	TRIG1 = 27 
	ECHO1 = 22
	GPIO.setup(TRIG1,GPIO.OUT)
	GPIO.setup(ECHO1,GPIO.IN)

	#print "Distance Measurement left In Progress"	

	GPIO.output(TRIG1, False)
	#print "Waiting For Sensor To Settle"
	time.sleep(0.09)

	GPIO.output(TRIG1, True)
	time.sleep(0.00001)
	GPIO.output(TRIG1, False)

	while GPIO.input(ECHO1)==0:
	  pulse_start1 = time.time()

	while GPIO.input(ECHO1)==1:
	  pulse_end1 = time.time()

	pulse_duration1 = pulse_end1 - pulse_start1

	distance1_r = pulse_duration1 * 17151

	distance1_r = round(distance1_r, 2)
	
	TRIG = 23 
	ECHO = 24
	GPIO.setup(TRIG,GPIO.OUT)
	GPIO.setup(ECHO,GPIO.IN)

	print "Distance Measurement right In Progress"	

	GPIO.output(TRIG, False)
	#print "Waiting For Sensor To Settle"

	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)

	while GPIO.input(ECHO)==0:
	  pulse_start = time.time()

	while GPIO.input(ECHO)==1:
	  pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151

	distance = round(distance, 2)
	
	
	print distance1_r,distance
	

	GPIO.cleanup()
	
	return distance1_r,distance
	
def sr_04_fired():
	

	print "Distance Measurement In Progress"	

	GPIO.output(TRIG, False)
	print "Waiting For Sensor To Settle"
	time.sleep(0.1)

	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)

	while GPIO.input(ECHO)==0:
	  pulse_start = time.time()

	while GPIO.input(ECHO)==1:
	  pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151

	distance = round(distance, 2)
	print distance
	
	return distance

time.sleep(3)
for x in range(1, 10):

	sr_04_both()
	#sr_04_right()

#points_list = [(160, 160), (136, 160), (150, 200), (200, 180), (120, 150), (145, 180)]

#for point in points_list:
#	cv.circle(img, point, point_size, point_color, thickness)


#cv.circle(img, (160, 160), 60, point_color, 0)
cv.imwrite("mapping.jpg", img)
#cv.namedWindow("image")
#cv.imshow('image', img)
#cv.waitKey (10000) 
#cv.destroyAllWindows()

img = np.zeros((1080, 1920, 3), np.uint8) 
#sr_mapping_theta(1000,500,img,math.radians(30),4)
#draw_car_shape(1000,500,img,math.radians(-60),4)
#draw_sr_area_left(48,1000,500,img,math.radians(-60),4)
#draw_sr_area_right(48,1000,500,img,math.radians(-60),4)
#cv2.circle(img, (1000,500), 10,(0, 0, 255)  , 4)

#cv2.imwrite("mapping_area'.jpg", img)

#sr_mapping_theta(300,500,img,math.radians(0),4)

#sr_mapping_theta(1500,100,img,math.radians(15),4)
