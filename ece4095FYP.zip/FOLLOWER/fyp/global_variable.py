#===================================================================================
#
#	LOCATION TO STORE BASIC GLOBAL VARIABLES
#
#===================================================================================

# what we are testing
DEBUGGER_ON = True
LOGGER_ON = False
SERIAL_ON = False
PRINT_ON = False
SOCKET_ON = False
IS_MASTER = False

socket_setup = False

# socket communication globals
sock = 0
port = 12347
client_host = '192.168.42.213'
follower_host = '192.168.42.213'
master_host = '192.168.42.213'


#Jamie's House
#follower_host = '192.168.0.8'
#maser_host = '192.168.0.10'

# logging globals
file = 0
ser = 0

# Clock times
end = 0
start = 0

# Camera
camera_status = "blank"

compass = 0.0



