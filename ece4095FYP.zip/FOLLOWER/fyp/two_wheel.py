
def car_coordinate(vl,vr,index,delta_t,theta_t)
	vl=vl*index
	vr=vr*index

	L=26.1
	v_robot=(vr+vl)/2
	w_robot=(vr-vl)/L

	theta_t=theta_t+w*delta_t
	x_robot=x+v_robot*math.cos(theta_t)*delta_t
	y_robot=y+v_robot*math.sin(theta_t)*delta_t
	return x_robot, y_robot,theta_t
