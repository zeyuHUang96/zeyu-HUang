from scipy.spatial import distance as dist
from picamera.array import PiRGBArray
from picamera import PiCamera
from imutils import perspective
from imutils import contours
import time
import cv2
import imutils
import numpy as np
import math
import serial
import os
import getopt
import sys
from socket import *
from socket import error as socket_error
import time


import global_variable as g0
import laser_globals as g1
import communication, my_serial, my_socket

import RPi.GPIO as GPIO
import math


def PID():
    print "PID phase3 is running\n"

    g1.e_angle_sum = g1.e_angle_sum + g1.e_angle
    g1.motorspeed = g1.Kp * (g1.e_angle) + g1.Kd * (g1.e_angle-g1.e_angle_prev) + g1.Ki * (g1.e_angle_sum)
    g1.e_angle_sum = g1.e_angle_sum + g1.e_angle
    g1.e_angle_prev = g1.e_angle

    g1.rightMotorSpeed = 100 - g1.motorspeed*0.04
    g1.leftMotorSpeed =100 +g1.motorspeed*0.04
    if (g1.rightMotorSpeed > 110):
        g1.rightMotorSpeed = 110
    elif (g1.rightMotorSpeed < 96):
        g1.rightMotorSpeed = 96
    if (g1.leftMotorSpeed > 110):
        g1.leftMotorSpeed = 110
    elif (g1.leftMotorSpeed < 96):
        g1.leftMotorSpeed = 96
	
    l_left = int(g1.leftMotorSpeed)
    l_right= int(g1.rightMotorSpeed)
    
    
    print "speed here phase3 is running\n\n\n\n"
    print l_left, l_right
    if (g0.SERIAL_ON):
        my_serial.motors(l_right, -1*l_left)
    return l_left, l_right
        #time.sleep(0.5)
        

def capture(l_frame,out):
    print "capture phase3 is running\n"

    l_success1=0
    g1.image = l_frame.array
    l_rotmatrix = cv2.getRotationMatrix2D((640,0),-0.2,1)
    g1.image = cv2.warpAffine(g1.image, l_rotmatrix,(640,480))

    l_b, l_g, l_r = cv2.split(g1.image)

    l_max_intensity = 255#np.amax(l_r)
    l_min_intensity = 100#np.amin(l_r)
    l_thresh_value, g1.thresh = cv2.threshold(l_r,l_min_intensity, l_max_intensity, cv2.THRESH_BINARY)
    #l_thresh_value, g1.thresh = cv2.threshold(l_r,l_max_intensity-(l_max_intensity-l_min_intensity)/2, 255, cv2.THRESH_BINARY)
    l_cnts = cv2.findContours(g1.thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    l_cnts = l_cnts[1]

    dots = 0
    # l_cnts should run for every dot detected
    # will highlight where the dots are


    for g1.c in l_cnts:
        print cv2.contourArea(g1.c) 
        if cv2.contourArea(g1.c) >120:
                l_cArea = cv2.contourArea(g1.c)
                dots = dots + 1
                
        else:
            continue
                
        l_box = cv2.minAreaRect(g1.c)
        l_box = cv2.cv.BoxPoints(l_box) if imutils.is_cv2() else cv2.boxPoints(l_box)
        l_box = np.array(l_box, dtype="int")
        l_box = perspective.order_points(l_box)

        l_max_x = int(max(l_box[0][0],l_box[1][0],l_box[2][0],l_box[3][0]) + 10)
        if l_max_x > 640:
            l_max_x = 640
        l_min_x = int(min(l_box[0][0],l_box[1][0],l_box[2][0],l_box[3][0]) - 10)
        if l_min_x < 0:
            l_min_x = 0
        l_max_y = int(max(l_box[0][1],l_box[1][1],l_box[2][1],l_box[3][1]) + 10)
        if l_max_y > 480:
            l_max_y = 480
        l_min_y = int(min(l_box[0][1],l_box[1][1],l_box[2][1],l_box[3][1]) - 10)
        if l_min_y < 0:
            l_min_y = 0
            
        l_box_vals = g1.thresh[l_min_y:l_max_y,l_min_x:l_max_x]

        # Calculate the x centroid
        l_sum_x = l_box_vals.sum(axis=0);
        l_x_vals = np.arange(len(l_sum_x))
        l_xi = l_sum_x*l_x_vals
        l_sum_xi = np.sum(l_xi)
        l_sum_i = np.sum(l_sum_x)
        l_rel_centroid_x = l_sum_xi/l_sum_i
        l_xcoords = range(l_min_x,l_max_x+1)
        l_centroid_x = l_xcoords[l_rel_centroid_x]
        #l_xcoords = range(int(l_min_x),int(l_max_x)+1)
        #l_centroid_x = l_xcoords[int(l_rel_centroid_x)]

        # Calculate the y centroid
        l_sum_y = l_box_vals.sum(axis=1);
        l_y_vals = np.arange(len(l_sum_y))
        l_yi = l_sum_y*l_y_vals #y*i
        l_sum_yi = np.sum(l_yi)
        l_rel_centroid_y = l_sum_yi/l_sum_i
        l_ycoords = range(l_min_y,l_max_y+1)
        l_centroid_y = l_ycoords[l_rel_centroid_y]
        #l_ycoords = range(int(l_min_y),int(l_max_y)+1)
        #l_centroid_y = l_ycoords[int(l_rel_centroid_y)]


        if dots<3:
            g1.laserdot[dots-1][0] = l_centroid_x
            g1.laserdot[dots-1][1] = l_centroid_y
       

    #OUT OF CNTLOOP
    if dots == 2:
        if(g1.dots_prev!=2):
            print("Two dots successfully found")
        if g1.laserdot[0][0] < g1.laserdot[1][0]:
            g1.frontdot[0] = g1.laserdot[0][0]
            g1.frontdot[1] = g1.laserdot[0][1]
            g1.backdot[0] = g1.laserdot[1][0]
            g1.backdot[1] = g1.laserdot[1][1]
        else:
            g1.frontdot[0] = g1.laserdot[1][0]
            g1.frontdot[1] = g1.laserdot[1][1]
            g1.backdot[0] = g1.laserdot[0][0]
            g1.backdot[1] = g1.laserdot[0][1]
        if (g0.DEBUGGER_ON):
            cv2.drawContours(g1.image, [l_box.astype("int")], -1, (0, 255, 0), 2)
            cv2.circle(g1.image, (l_centroid_x, l_centroid_y), 4, (255, 0, 0), -1)
            cv2.putText(g1.image, "front dot", (g1.frontdot[0], g1.frontdot[1]),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
            cv2.putText(g1.image, "back dot", (g1.backdot[0],g1.backdot[1]),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
            print("g1.frontdot:"+ str(g1.frontdot))
            print("g1.backdot:"+ str(g1.backdot))
        # Convert the y coordinates to a coordinate system where the centre line is zero
        g1.frontdot[1] = g1.frontdot[1] - g1.yzero
        g1.backdot[1] = g1.backdot[1] - g1.yzero

        # Convert the x coordinates to a coordinate system where no-man's land is zero
        g1.frontdot[0] = g1.frontdot[0] - g1.xzero
        g1.backdot[0] = g1.backdot[0] - g1.xzero
        
            
        if (g1.frontdot[0] > 0) or (g1.backdot[0] < 0):
            if(g1.dots_prev!=2):
                print("Interference, dots found in the same sector")
              
        else:
            # If valid dots have been found, set valid dots to tru
            g1.validdots = True
            
            # Find the differences in x and y directions for each dot
            g1.xdiff = g1.backdot[0] - g1.frontdot[0]
            g1.ydiff = g1.backdot[1] - g1.frontdot[1]

            # Calculate the current l_angle to the laser line
            #g1.c_angle = math.degree(math.atan(g1.ydiff/g1.xdiff))
            l_angle = float(float(g1.ydiff) / float(g1.xdiff))
            if (g1.ydiff < 0):
                g1.c_angle = float(-math.degrees(math.atan(l_angle)))
            else:
                g1.c_angle = float(math.degrees(math.atan(l_angle)))
            #g1.c_angle = math.degrees(math.acos(g1.xdiff/math.sqrt((g1.xdiff**2) + (g1.ydiff**2))))
  
            # Calculate the orthogonal distance to the laser line from the axle
            # Calculate the gradient between the lines
            g1.c = g1.backdot[1] - l_angle*g1.backdot[0] # Calculate the offset of the lines from the centreline
            g1.orth_dist = l_angle*(g1.axle_pos) + g1.c
            #g1.orth_dist = round(g1.orth_dist)
            
            #print (g1.orth_dist)
            l_angle2 = float(float(-g1.orth_dist) / float(g1.dr))
            g1.t_angle = float(math.degrees(math.atan(l_angle2)))

            if g1.ydiff > 0:
                g1.c_angle = -1*g1.c_angle #l_Angle is negative if yf<yb

            
            g1.e_angle = g1.t_angle - g1.c_angle

            l_success1 = 1

    else:
        #if (g0.SERIAL_ON):
            #g0.ser.write("2")
        #np.append(log, "reset")
        if (g0.LOGGER_ON):
            g0.file.write("reset\n")
        if (g0.PRINT_ON):
            print("didn't find 2 dots")
            print dots
        l_success1 = 0             

    if (g0.DEBUGGER_ON==0):
        cv2.circle(g1.image, (int(g1.xzero + g1.axle_pos), int(g1.yzero + g1.orth_dist)), 4, (255, 255, 0), -1)
        cv2.drawContours(g1.image, [g1.axle_line.astype("int")], -1, (0, 255, 0), 1)
        cv2.drawContours(g1.image, [g1.centre_line_x.astype("int")], -1, (0, 255, 255), 1)
        cv2.drawContours(g1.image, [g1.centre_line_y.astype("int")], -1, (0, 255, 255), 1)
        cv2.putText(g1.image, "(x) ->", (g1.xzero+3,g1.yzero-3),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
        cv2.putText(g1.image, "(y)\/", (g1.xzero+3,g1.yzero+15),cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)
        cv2.imshow("Thresh", g1.thresh)
        cv2.imshow("Frame", g1.image)
        out.write(g1.image)    

    if (g0.PRINT_ON):
        g0.end = time.time()
        print("xdiff:" +str(g1.xdiff)+ "   ydiff:" +str(g1.ydiff)+ "   m:"+ str(g1.m) )
        print ("Orthogonal distance (pixels): %d"%g1.orth_dist)
        print ("Current l_angle: %3f"%(g1.c_angle))
        print ("Target l_angle: %4f"%(g1.t_angle))
        print ("Error l_angle: %5f"%(g1.e_angle))
        print("Time taken: "+ str(g0.end - g0.start))
        print("")

    g1.dots_prev = dots
    
    return l_success1


def start_camera():
    #print "start_camera phase3 is running\n"

    try:
        g1.camera = PiCamera()
        g1.camera.resolution = (640, 480)
        
        g1.camera.framerate = 90
        
        g1.camera.exposure_mode = "off"
        g1.camera.awb_mode = "off"
        g1.camera.awb_gains = [0.9,0]
        g1.camera.brightness = 50
        g1.camera.saturation = 100
        g1.camera.contrast = 0
        g1.rawCapture= 0
        g1.rawCapture = PiRGBArray(g1.camera, size=(640, 480))
        print("Camera initialised for laser detection")
        time.sleep(0.1)
        return "success"
    except:
        print("Error: could not initialise camera for laser detection")
        return error


def initiate_laser_globals():
    
    g1.Kp = 12
    g1.Kd = 6
    g1.Ki = 0    


def close_camera():
    g1.camera.close()
    del g1.camera


def run_master():

    print("waiting for follower to follow laser...")
    my_socket.sync("END OF LASER_DETECT\n\n")


def run_follower():
    print "run_follower phase3 is running\n"
    
    #if g0.camera_status == "blank":
    #    start_camera()
    start_camera()
    initiate_laser_globals()

    if (g0.LOGGER_ON):
        g0.file.write("\n"+str(g1.Kp)+" | "+str(g1.Kd)+" | "+str(g1.Kd)+"\n")

    if (g0.PRINT_ON):
        g0.start = time.time()

    #g1.rawCapture.truncate(0)

    count = 0
    #fourcc=cv2.cv.CV_FOURCC(*'XVID')
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out=cv2.VideoWriter('phase3.avi',fourcc,5,(640,480))
    time7 = time.time()
    
    theta=math.radians(0)
    img = np.zeros((1920, 1920, 3), np.uint8)
    img2 = np.zeros((1920, 1920, 3), np.uint8)
    x=0
    y=0
    v_left=0
    v_right=0
    for l_frame in g1.camera.capture_continuous(g1.rawCapture, format="bgr", use_video_port=True):
        count = count + 1
        time1 = time.time()
        print "frame capture: "+str(time7-time1)
        l_success = capture(l_frame,out)
        time2 = time.time()
        print "capture time: "+str(time2-time1)

        if (l_success):
            time3 = time.time()
            v_left,v_right=PID()
            l_distance=sr_04_left()
	    r_distance=sr_04_right()
            time4 = time.time()
            print "PID time: "+str(time4-time3)
	    x,y,theta=car_coordinate(v_left,v_right,0.4,time4-time1,theta,x,y)#0.4 100
	    draw_sr_area_left(l_distance,x+100,y+900,img,theta,4)
	    draw_sr_area_right(r_distance,x+100,y+900,img,theta,4)
	    draw_car_shape(x+100,y+900,img,theta,4)
	    draw_sr_area_left_fan_shape(l_distance,x+100,y+900,img2,theta,4)
	    draw_sr_area_right_fan_shape(r_distance,x+100,y+900,img2,theta,4)
	    draw_car_shape(x+100,y+900,img2,theta,4)
	else:
            l_distance=sr_04_left()
	    r_distance=sr_04_right()
            time4 = time.time()
            print "not on time: "+str(time4-time1)
	    x,y,theta=car_coordinate(v_left,v_right,0.4,time4-time1,theta,x,y)#0.4 100
	    draw_sr_area_left(l_distance,x+100,y+900,img,theta,4)
	    draw_sr_area_right(r_distance,x+100,y+900,img,theta,4)
	    draw_car_shape(x+100,y+900,img,theta,4)
	    draw_sr_area_left_fan_shape(l_distance,x+100,y+900,img2,theta,4)
	    draw_sr_area_right_fan_shape(r_distance,x+100,y+900,img2,theta,4)
	    draw_car_shape(x+100,y+900,img2,theta,4)

            #time3 = time.time()
            #v_left,v_right=PID()
            #x=g1.c_x
            #y=g1.c_y
            #r_distance,l_distance=sr_04_both()
            #time4 = time.time()
            #print "PID time: "+str(time4-time3)
            #angle_in=g1.c_angle
            #dt=time4-time3
            #g1.c_x,g1.c_y,theta_car=car_coordinate(v_left,v_right,0.01,dt,angle_in,x,y)
            ##draw mapping
            #scale_index=4
            #draw_car_shape(g1.c_x,g1.c_y,img,theta_car,scale_index)
            #draw_sr_area_left(l_distance,g1.c_x,g1.c_y,img,theta_car,scale_index)
            #draw_sr_area_right(r_distance,g1.c_x,g1.c_y,img,theta_car,scale_index)
            #print g1.c_x,g1.c_y,theta_car

        if (g0.PRINT_ON):
            g0.start = g0.end

        if count > 300:
            break

        # don't get rid of any of this stuff
        l_key = cv2.waitKey(1) & 0xFF
        if l_key == ord("q"):
           break
        g1.rawCapture.truncate(0)
        
    #np.savetxt("data.csv", log, delimiter=",")
    if (g0.SERIAL_ON):
        g0.ser.write("2")

    if (g0.PRINT_ON):
        print("end of the run")

    my_socket.sync("END OF LASER_DETECT\n\n")
    img = cv2.flip(img, 1)
    cv2.imwrite("mapping_area'.jpg", img)
    img2 = cv2.flip(img2, 1)
    cv2.imwrite("mapping_area_no_extension'.jpg", img2)
    time.sleep(1)

def car_coordinate(vl,vr,index,delta_t,theta_t,x,y):# generate x,y is in  coorindate in picture.
	index=index*0.9
	vl=50+0.5*vl
	vr=50+0.5*vr
	vl=vl*index
	vr=vr*index
	L=26.1
	v_robot=(vr+vl)/2
	w_robot=(vr-vl)/L

	theta_t=theta_t+w_robot*delta_t
	x_robot=x+v_robot*math.cos(theta_t)*delta_t
	y_robot=y-v_robot*math.sin(theta_t)*delta_t
	return x_robot, y_robot,theta_t

def sr_04_left():
	GPIO.setmode(GPIO.BCM)
	TRIG = 23 
	ECHO = 24
	GPIO.setup(TRIG,GPIO.OUT)
	GPIO.setup(ECHO,GPIO.IN)

	print "Distance Measurement left In Progress"	

	GPIO.output(TRIG, False)
	#print "Waiting For Sensor To Settle"
	time.sleep(0.0)
	
	pulse_start1=time.time()
	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)
	
	pulse_start = 0
	pulse_end = 0
	pulse_start1=time.time()
	while GPIO.input(ECHO)==0:
		pulse_start = time.time()
		if pulse_start-pulse_start1>=0.057491:
			pulse_end=pulse_start+0.017491
			break
	while GPIO.input(ECHO)==1:
		pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151
	
	if distance>=600:
		distance =299.99

	distance = round(distance, 2)
	print distance
	GPIO.cleanup()
	
	return distance
	


def sr_04_right():
	GPIO.setmode(GPIO.BCM)
	TRIG = 27 
	ECHO = 22
	GPIO.setup(TRIG,GPIO.OUT)
	GPIO.setup(ECHO,GPIO.IN)

	print "Distance Measurement right In Progress"	

	GPIO.output(TRIG, False)
	#print "Waiting For Sensor To Settle"
	time.sleep(0.0)
	pulse_start1=time.time()
	GPIO.output(TRIG, True)
	time.sleep(0.00001)
	GPIO.output(TRIG, False)
	
	pulse_start = 0
	pulse_end = 0
	
	while GPIO.input(ECHO)==0:
		pulse_start = time.time()
		if pulse_start-pulse_start1 >=0.057491:
			pulse_end=pulse_start+0.017491
			break

	while GPIO.input(ECHO)==1:
	  pulse_end = time.time()

	pulse_duration = pulse_end - pulse_start

	distance = pulse_duration * 17151
	if distance>=300:
		distance =299.99

	distance = round(distance, 2)
	print distance
	GPIO.cleanup()
	
	return distance


def draw_car_shape(x,y,img,theta,scale_index):# draw car in picture
    
    l1=10.6066*scale_index
    l2=14.5774*scale_index
    w1=7.5*scale_index
    theta1=math.radians(45)
    theta2=math.radians(30.9638)

    x1=int(x+l1*math.cos(theta+theta1))
    y1=int(y-l1*math.sin(theta+theta1))
    x2=int(x+l1*math.cos(theta1-theta))
    y2=int(y+l1*math.sin(theta1-theta))
    x3=int(x-l2*math.cos(theta+theta2))
    y3=int(y+l2*math.sin(theta+theta2))
    x4=int(x-l2*math.cos(theta2-theta))
    y4=int(y-l2*math.sin(theta2-theta))
    pts_r= np.array([[x1,y1],[x2,y2],[x3,y3],[x4,y4]])
    cv2.fillConvexPoly(img,pts_r,(255,255,255))
	
	
def draw_sr_area_left(l,x,y,img,theta,scale_index):#finish 
    
    if l>=190:
	l=190
    l0=int(11.3936*scale_index)
    l=int(l*scale_index)
    x1=-1*int(9.3367*scale_index*math.cos(theta+math.radians(9.8271)))+int(x)
    y1=int(9.3367*scale_index*math.sin(theta+math.radians(9.8271)))+int(y)
    
    angle=7.6-3*l/200
    theta2=-1*(180/math.pi*theta+90)
    
    cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)
    
    robot_x=x1-int(3*math.sin(theta)*scale_index)
    robot_y=y1-int(3*math.cos(theta)*scale_index)
    
    point_x_left=x1-int(0.2*l*math.sin(theta)*scale_index)
    point_y_left=y1-int(0.2*l*math.cos(theta)*scale_index)
    h =l*0.06
    x1=int(robot_x+h*math.cos(theta))
    y1=int(robot_y-h*math.sin(theta))
    x4=int(robot_x-h*math.cos(theta))
    y4=int(robot_y+h*math.sin(theta))
    x2=int(point_x_left+h*math.cos(theta))
    y2=int(point_y_left-h*math.sin(theta))
    x3=int(point_x_left-h*math.cos(theta))
    y3=int(point_y_left+h*math.sin(theta))
    pts = np.array([[x1,y1],[x2,y2],[x3,y3],[x4,y4]])
    cv2.fillConvexPoly(img,pts,(255,255,255))
    
def draw_sr_area_right(l,x,y,img,theta,scale_index):#finished
    if l>=190:
	l=190
	
    l0=int(11.3936*scale_index)
    l=int(l*scale_index)
    x1=-1*int(9.3367*scale_index*math.cos(-theta+math.radians(9.8271)))+int(x)
    y1=-1*int(9.3367*scale_index*math.sin(-theta+math.radians(9.8271)))+int(y)
	    
    angle=7.6-3*l/200
    theta2=90-180/math.pi*theta#(180/math.pi*theta+90)
    
    cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)

    robot_x=x1+int(3*math.sin(theta)*scale_index)
    robot_y=y1+int(3*math.cos(theta)*scale_index)
    h =l*0.06
    point_x_right=x1+int(0.2*l*math.sin(theta)*scale_index)
    point_y_right=y1+int(0.2*l*math.cos(theta)*scale_index)
    
    x1_r=int(point_x_right+h*math.cos(theta))
    y1_r=int(point_y_right-h*math.sin(theta))
    x4_r=int(point_x_right-h*math.cos(theta))
    y4_r=int(point_y_right+h*math.sin(theta))
    x2_r=int(robot_x+h*math.cos(theta))
    y2_r=int(robot_y-h*math.sin(theta))
    x3_r=int(robot_x-h*math.cos(theta))
    y3_r=int(robot_y+h*math.sin(theta))
    
    pts_r= np.array([[x1_r,y1_r],[x2_r,y2_r],[x3_r,y3_r],[x4_r,y4_r]])
    cv2.fillConvexPoly(img,pts_r,(255,255,255))
		
def draw_sr_area_right_fan_shape(l,x,y,img,theta,scale_index):#finished
    if l>=190:
	l=190
    l0=int(11.3936*scale_index)
    l=int(l*scale_index)
    x1=-1*int(9.3367*scale_index*math.cos(-theta+math.radians(9.8271)))+int(x)
    y1=-1*int(9.3367*scale_index*math.sin(-theta+math.radians(9.8271)))+int(y)
	    
    angle=7.6-3*l/200
    theta2=90-180/math.pi*theta#(180/math.pi*theta+90)
    
    cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)
	
def draw_sr_area_left_fan_shape(l,x,y,img,theta,scale_index):#finish
    if l>=190:
	l=190
    l0=int(11.3936*scale_index)
    l=int(l*scale_index)
    x1=-1*int(9.3367*scale_index*math.cos(theta+math.radians(9.8271)))+int(x)
    y1=int(9.3367*scale_index*math.sin(theta+math.radians(9.8271)))+int(y)
    
    angle=7.6-3*l/200
    theta2=-1*(180/math.pi*theta+90)
    
    cv2.ellipse(img,(x1,y1),(l+l0,l+l0),theta2,-1*angle,angle,(255,255,255),-1)

def sr_04_both():
    GPIO.setmode(GPIO.BCM)
    TRIG1 = 27 
    ECHO1 = 22
    GPIO.setup(TRIG1,GPIO.OUT)
    GPIO.setup(ECHO1,GPIO.IN)

    #print "Distance Measurement left In Progress"	

    GPIO.output(TRIG1, False)
    #print "Waiting For Sensor To Settle"
    time.sleep(0.09)

    GPIO.output(TRIG1, True)
    time.sleep(0.00001)
    GPIO.output(TRIG1, False)

    while GPIO.input(ECHO1)==0:
	pulse_start1 = time.time()

    while GPIO.input(ECHO1)==1:
	pulse_end1 = time.time()

    pulse_duration1 = pulse_end1 - pulse_start1

    distance1_r = pulse_duration1 * 17151

    distance1_r = round(distance1_r, 2)
    
    TRIG = 23 
    ECHO = 24
    GPIO.setup(TRIG,GPIO.OUT)
    GPIO.setup(ECHO,GPIO.IN)

    print "Distance Measurement right In Progress"	

    GPIO.output(TRIG, False)
    #print "Waiting For Sensor To Settle"

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO)==0:
	pulse_start = time.time()

    while GPIO.input(ECHO)==1:
	pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start

    distance = pulse_duration * 17151

    distance = round(distance, 2)
    
    
    print distance1_r,distance
    

    GPIO.cleanup()
    
    return distance1_r,distance


def run():
    print "run phase3 is running\n"
    
    my_socket.sync("PHASE 3 START")

    if (g0.IS_MASTER == "FOLLOWER"):
        run_follower()
    elif (g0.IS_MASTER=="MASTER"):
        run_master()

    my_socket.sync("PHASE 3 END\n\n")



