from scipy.spatial import distance as dist
from picamera.array import PiRGBArray
from picamera import PiCamera
from imutils import perspective
from imutils import contours
import time
import cv2
import imutils
import numpy as np
import math
import serial
import os
import getopt
import sys
from socket import *
from socket import error as socket_error
from multiprocessing import Pool
import mag3110_master, mag3110_follower

import global_variable as g0
import laser_globals as g1
import communication, my_socket, my_serial


def PID(error):
    print "PID phase2 is running slave"

    Kp = 3

    motorspeed = Kp*(error)

    if (abs(motorspeed) < 5):
        if motorspeed < 0:
            motorspeed = -5
        else: 
            motorspeed = 5
    g1.error_prev = error
    
    if g0.IS_MASTER == "FOLLOWER":
        rightMotorSpeed = 0 - motorspeed
        leftMotorSpeed = 0 + motorspeed 
    else:
        rightMotorSpeed = 0 - motorspeed
        leftMotorSpeed = 0 + motorspeed   

    if (rightMotorSpeed > 100):
        rightMotorSpeed = 100
    elif (rightMotorSpeed < -100):
        rightMotorSpeed = -100
    if (leftMotorSpeed > 100):
        leftMotorSpeed = 100
    elif (leftMotorSpeed < -100):
        leftMotorSpeed = -100

    left = str(int(leftMotorSpeed))
    while len(left)<4:
        left = " "+left
    right = str(int(rightMotorSpeed))
    while len(right)<4:
        right = " "+right
    print left, right
    if (g0.SOCKET_ON):
        my_socket.send_msg(left+right, 1)
        my_socket.sync("change speed")

    return left


def compass_error(current, dest):
    print "compass_error phase2 is running slave"

    error = current - float(dest)
    if error > 180:
        error = error - 360
    elif error < -180:
        error = error + 360

    return error


def align_compass(goal):
    
    print "align_compass phase2 is running slave"

    print "goal found as: "+str(goal)
    current = my_socket.recv_compass()
    error = compass_error(current, goal)
    check = 0
    error_max = 5

    while (check == 0):
        while abs(error) > error_max:
            check = 0
            PID(error)
            current = my_socket.recv_compass()
            error = compass_error(current, goal)
            print error, current, goal
            time.sleep(0.2)
        if check == 0:
            my_socket.send_msg("00000000", 1)
            my_socket.sync("change speed")
            time.sleep(1)
            current = my_socket.recv_compass()
            error = compass_error(current, goal)
        if abs(error) < error_max:
            check = 1
    print "final error found as: "+str(error)


def pass_offset(offset, goal):
    
    print "pass_offset phase2 is running slave"
    current = my_socket.recv_compass()
    error = compass_error(current, goal)
    print error, offset, goal
    if offset > 0:
        if error > offset:
            result = 0
        else:
            result = 1
    else:
        if error < offset:
            result = 0
        else:
            result = 1

    return result


def capture(frame,out):

    dots = 0

    img = frame.array
    rotmatrix = cv2.getRotationMatrix2D((640,0),-0.2,1)
    img = cv2.warpAffine(img, rotmatrix,(640,480))

    b_img, g_img, r_img = cv2.split(img)

    max_intensity = 255#np.amax(l_r)
    min_intensity = 100#np.amin(l_r)
    thresh_value, thresh = cv2.threshold(r_img, min_intensity, max_intensity, cv2.THRESH_BINARY)
    l_cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    l_cnts = l_cnts[1]

    for c in l_cnts:   
        if cv2.contourArea(c) > 200:
                l_cArea = cv2.contourArea(c)
                dots = dots + 1
        else:
            continue

    if dots > 0 and g0.PRINT_ON:
        print "dots found"
    out.write(img)    
    return dots


def start_camera():
    try:
        g1.camera = PiCamera()
        g1.camera.resolution = (640, 480)
        
        g1.camera.framerate = 90
        
        g1.camera.exposure_mode = "off"
        g1.camera.awb_mode = "off"
        g1.camera.awb_gains = [0.9,0]
        g1.camera.brightness = 50
        g1.camera.saturation = 100
        g1.camera.contrast = 0
        
        g1.rawCapture = PiRGBArray(g1.camera, size=(640, 480))
        print("Camera initialised for laser detection")
        time.sleep(0.1)
        return "success"
    except:
        print("Error: could not initialise camera for laser detection")
        return error 


def close_camera():
    g1.camera.close()
    del g1.camera


def change_speed(direction, speed):
    
    # STATE 1: looking left + right 
    left = speed
    right = speed

    if direction == 0:
        left = -left
    else:
        right = -right

    left = str(left)
    while len(left) < 4:
        left = " "+left
    right = str(right)
    while len(right) < 4:
        right = " "+right

    my_socket.send_msg(left+right, 1)
    time.sleep(0.1)
    my_socket.sync("change speed")

    return direction


def run_follower3():
    print "run_follower3 is running slave\n"

    #direction 0 is left
    goal = my_serial.compass()
    align_compass(goal)

    my_serial.camera("DOWN")

    direction = 0
    speed = 15
    offset = 30

    g0.camera_status = start_camera()

    count = 0
    in_range = 1
    dots_max = 1
    direction = change_speed(direction, speed)
    for l_frame in g1.camera.capture_continuous(g1.rawCapture, format="bgr", use_video_port=True):
        dots = capture(l_frame)
        if dots > dots_max:
            dots_max = dots

        if dots > 0:
            direction = change_speed(0, 0)
            if dots == 2:
                break
            elif dots == 1:
                dots_max = 1
                speed = 5
                direction = change_speed(abs(1-direction), speed)
            elif dots == 0:
                dots_max = 0
                speed = 8
                direction = change_speed(abs(1-direction), speed)
        if dots_max > 0 and dots == 0:
            direction = change_speed(abs(1-direction), speed)

        if pass_offset(-offset, goal) == 0 and direction == 1 and count%10 == 0:
            print "passed offset"
            direction = change_speed(abs(1-direction), speed)
        elif pass_offset(offset, goal) == 0 and direction == 0 and count%10 == 0:
            print "passed offset"
            direction = change_speed(abs(1-direction), speed)


        l_key = cv2.waitKey(1) & 0xFF
        if l_key == ord("q"):
           break
        count = count + 1
        g1.rawCapture.truncate(0)
    g1.rawCapture.truncate(0)


def change_state(in_state, prev_direction):
    print "change_state is running slave\n"


    # STATE1: stop, 
    #         how many dots? 0->2, 1->7, ...
    # STATE2: turn left
    #           if offset < -20 go to STATE 3
    #           if dots go to STATE4
    # STATE3:   turn right
    #           if offset > 20  go to STATE 2 and increase offset
    #           if dots go to STATE 4
    # STATE4:   stop
    #           how many dots? 0->5, 1->8
    # STATE5:   same as STATE 2 (half speed) exit to STATE 4 with succes
    # STATE6:   same as STATE 3 (half speed)
    # STATE7:   stop
    #           how many dots? 0->5, 1->8
    # STATE8:   go direction
    #           dots = 1 continue
    #           dots = 2 go to state 10
    #           dots = 0 go to state 9
    # STATE9:   go opposite direction
    #           dots = 1 continue
    #           dots = 2 go to state 10
    #           dots = 0 continue
    # STATE10:  stop
    #           dots = 2 SUCCESS
    #           dots = 1 go to state 9 
    #  
    STATE = in_state
    direction = prev_direction
    if in_state == 1:
        left = 0
        right = 0
        direction = 0
    elif in_state == 2:
        left = -15
        right = 15
        direction = 0
    elif in_state == 3:
        left = 15
        right = -15
        direction = 1
    elif in_state == 4:
        left = 0
        right = 0
    elif in_state == 5:
        if prev_direction == 0:
            left = 8
            right = -8
            direction = 1
        else:
            left = -8
            right = 8
            direction = 0
    elif in_state == 6:
        left = -8
        right = 8
        direction = 1
    elif in_state == 7:
        left = 0
        right = 0
    elif in_state == 8:
        if prev_direction == 0:
            left = -8
            right = 8
            direction = 0
        else:
            left = 8
            right = -8
            direction = 1
    elif in_state == 9:
        if prev_direction == 0:
            left = 5
            right = -5
            direction = 1
        else:
            left = -5
            right = 5
            
            direction = 0
    elif in_state == 10:
        left = 0
        right = 0 

    left = str(left)
    while len(left) < 4:
        left = " "+left
    right = str(right)
    while len(right) < 4:
        right = " "+right

    my_socket.send_msg(left+right, 1)
    my_socket.sync("change speed")

    if in_state == 10:
        my_socket.send_msg("end", 4)

    time.sleep(0.2)
    return STATE, direction


def run_follower2():
    # 0->left, 1->right

    # align the compasses to get an initial starting point
    #goal = my_serial.compass()
    #align_compass(goal)


    my_serial.camera("DOWN")
    direction = 0
    
    g0.camera_status = start_camera()
    
    offset = 30

    STATE, direction = change_state(1, direction)
    # STATE1: stop, 
    #         how many dots? 0->2, 1->7, 2->10
    # STATE2: turn left
    #           if offset < -20 go to STATE 3
    #           if dots go to STATE4
    # STATE3:   turn right
    #           if offset > 20  go to STATE 2 and increase offset
    #           if dots go to STATE 4
    # STATE4:   stop
    #           how many dots? 0->5, 1->8, 2->10
    # STATE5:   opposite to previous direction as STATE 2 (half speed) exit to STATE 4 with succes
    # STATE6:   same as STATE 3 (half speed)
    # STATE7:   stop
    #           how many dots? 0->5, 1->8
    # STATE8:   go direction
    #           dots = 1 continue
    #           dots = 2 go to state 10
    #           dots = 0 go to state 9
    # STATE9:   go opposite direction
    #           dots = 1 continue
    #           dots = 2 go to state 10
    #           dots = 0 continue
    # STATE10:  stop
    #           dots = 2 SUCCESS
    #           dots = 1 go to state 9 
    #  
    count = 0
    in_range = 1
    #fourcc=cv2.cv.CV_FOURCC(*'XVID')
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out=cv2.VideoWriter('phase2.avi',fourcc,5,(640,480))
    for l_frame in g1.camera.capture_continuous(g1.rawCapture, format="bgr", use_video_port=True):
        
        time1 = time.time()
        dots = capture(l_frame,out)
        print STATE, dots
        time2 = time.time()
        print "dot detection: "+str(time2 - time1)

        if STATE == 1:
            if dots == 0:
                STATE, direction = change_state(2, direction)
            elif dots == 1:
                STATE, direction = change_state(7, direction)
            elif dots == 2:
                STATE, direction = change_state(10, direction)
        elif STATE == 2:
            time5 = time.time()
            if count%10 == 0:
                #in_range = pass_offset(offset, goal)
                in_range=1
            time6=time.time()
            print "time to find offset: "+str(time6 - time5)
            if dots > 0:
                STATE, direction = change_state(4, direction)
            elif in_range == 0:
                STATE, direction = change_state(3, direction)
                offset = 2*offset
                in_range = 1
        elif STATE == 3:
            if count%10 == 0:
                #in_range = pass_offset(-offset, goal)
                in_range=1
            if dots > 0:
                STATE, direction = change_state(4, direction)
            elif in_range == 0:
                STATE, direction = change_state(2, direction) 
                in_range = 1
        elif STATE == 4:
            if dots == 0:
                STATE, direction = change_state(5, direction)
            elif dots == 1:
                STATE, direction = change_state(8, direction)
            elif dots == 2:
                STATE, direction = change_state(10, direction)
        elif STATE == 5:
            if count%10 == 0:
                #in_range = pass_offset(offset, goal)
                in_range=1
            if dots > 0:
                STATE, direction = change_state(4, direction)
            elif in_range == 0:
                STATE, direction = change_state(2, direction)
        elif STATE == 6:
            if count%10 == 0:
                #in_range = pass_offset(-offset, goal)
                in_range=1
            if dots > 0:
                STATE, direction = change_state(4, direction)
            elif in_range == 0:
                STATE, direction = change_state(2, direction)
                offset = 2*offset
        elif STATE == 7:
            if dots == 0:
                STATE, direction = change_state(2, direction)
            elif dots == 1:
                STATE, direction = change_state(8, direction)
            elif dots == 2:
                STATE, direction = change_state(10, direction)
        elif STATE == 8:
            if dots == 0:
                STATE, direction = change_state(9, direction)
            elif dots == 2:
                STATE, direction = change_state(10, direction)
        elif STATE == 9:
            if dots == 2:
                STATE, direction = change_state(10, direction)
        elif STATE == 10:
            break
  
        l_key = cv2.waitKey(1) & 0xFF
        if l_key == ord("q"):
           break
        time3 = time.time()
        print "other stuff: "+str(time3 - time2)
        count = count + 1
        g1.rawCapture.truncate(0)
    g1.rawCapture.truncate(0)

    close_camera()



def run_master():

    my_socket.wait_for_messages()


def run():
    print "phase2 is runing."
    my_socket.sync("PHASE 2 START")

    if (g0.IS_MASTER == "FOLLOWER"):
        run_follower2()         

    elif (g0.IS_MASTER == "MASTER"):
        run_master()

    my_socket.sync("PHASE 2 END\n\n")

