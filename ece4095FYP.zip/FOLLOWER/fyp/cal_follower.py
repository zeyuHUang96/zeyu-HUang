import mag3110_follower

compass = mag3110_follower.compass()
compass.calibrate()