import mag3110
import global_variable as g0

if (g0.IS_MASTER=="MASTER")
	print "Master Calibrating"
	compass = mag3110_master.compass()
	print compass.calibrate()

if (g0.IS_MASTER=="FOLLOWER")
	print "Follower Calibrating"
	compass = mag3110_follower.compass()
	print compass.calibrate()