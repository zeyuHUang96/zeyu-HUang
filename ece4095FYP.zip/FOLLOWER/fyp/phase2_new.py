from scipy.spatial import distance as dist
from picamera.array import PiRGBArray
from picamera import PiCamera
from imutils import perspective
from imutils import contours
import time
import cv2
import imutils
import numpy as np
import math
import serial
import os
import getopt
import sys
from socket import *
from socket import error as socket_error
from multiprocessing import Pool
import mag3110

import global_variable as g0
import laser_globals as g1
import communication


def capture(frame):

    dots = 0

    img = frame.array
    rotmatrix = cv2.getRotationMatrix2D((640,0),-0.2,1)
    img = cv2.warpAffine(img, rotmatrix,(640,480))

    b_img, g_img, r_img = cv2.split(img)

    max_intensity = 255#np.amax(l_r)
    min_intensity = 100#np.amin(l_r)
    thresh_value, thresh = cv2.threshold(r_img, min_intensity, max_intensity, cv2.THRESH_BINARY)
    l_cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    l_cnts = l_cnts[0]

    for c in l_cnts:   
        if cv2.contourArea(c) > 25:
                l_cArea = cv2.contourArea(c)
                dots = dots + 1
        else:
            continue

    if dots > 0 and g0.PRINT_ON:
        print "dots found"

    return dots


def align_compass():
    if g0.IS_MASTER == "FOLLOWER":
        direction = g0.compass.getBearing()
        communication.send_msg(direction)
        print "direction was found as: "+str(direction)
        communication.sync("END COMPASS ALIGN")
    else:
        goal = communication.recv_msg()
        while True:
            direction = 50#direction = g0.compass.getBearing()
            error =  float(goal) - float(direction)
            print error
        communication.sync("END COMPASS ALIGN")  

def start_camera():
    try:
        g1.camera = PiCamera()
        g1.camera.resolution = (640, 480)
        
        g1.camera.framerate = 90
        
        g1.camera.exposure_mode = "off"
        g1.camera.awb_mode = "off"
        g1.camera.awb_gains = [0.9,0]
        g1.camera.brightness = 50
        g1.camera.saturation = 100
        g1.camera.contrast = 0
        
        g1.rawCapture = PiRGBArray(g1.camera, size=(640, 480))
        print("Camera initialised for laser detection")
        time.sleep(0.1)
        return "success"
    except:
        print("Error: could not initialise camera for laser detection")
        return error 


def close_camera():
    g1.camera.close()
    del g1.camera


def change_scenario(SCENARIO):

    if SCENARIO == 1:
        SCENARIO = 1
        communication.socket_motors("right full")

    elif SCENARIO == 2:
        SCENARIO = 2
        communication.socket_motors("stop")

    elif SCENARIO == 3:
        SCENARIO = 3
        communication.socket_motors("left half")

    elif SCENARIO == 4:
        SCENARIO = 4
        communication.socket_motors("stop")

    elif SCENARIO == 5:
        SCENARIO = 5
        communication.socket_motors("right half")

    elif SCENARIO == 6:
        SCENARIO = 6
        communication.socket_motors("right quater")

    elif SCENARIO == 7:
        SCENARIO = 7
        communication.socket_motors("stop")

    elif SCENARIO == 8:
        SCENARIO = 8
        communication.socket_motors("left quater")

    elif SCENARIO == 9:
        SCENARIO = 9
        communication.socket_motors("stop")

    elif SCENARIO == 10:
        SCENARIO = 10
        communication.socket_motors("end")

    elif SCENARIO == 11:
        SCENARIO = 11
        communication.socket_motors("left half")

    return SCENARIO


def run_follower():

    communication.camera("DOWN")

    align_compass()


    
    g0.camera_status = start_camera()

        # SCENARIO 1: turning right, no dots found
        # SCENARIO 2: stop, >0 dots founds
        # SCENARIO 3: turning left half, no dots found
        # SCENARIO 4: stop, >0 dots found
        # SCENARIO 5: turning right half, no dots found
        # SCENARIO 6: turning left quater, 1 dot found
        # SCENARIO 7: stop, >1 dots found
        # SCENARIO 8: turning right quater, 1 dot found
        # SCENARIO 9: stop, >1 dot found
        # SCENARIO 10: break
        # SCENARIO 11: go back left if went the wrong way





    communication.sync("DOT_DETECT SETUP")
    SCENARIO = change_scenario(1)   


    for l_frame in g1.camera.capture_continuous(g1.rawCapture, format="bgr", use_video_port=True):
        dots = capture(l_frame)

        print SCENARIO, dots

        if SCENARIO == 1:
        # SCENARIO 1: turning right, no dots found
            if dots > 0:
                SCENARIO = change_scenario(2)

        elif SCENARIO == 2:
        # SCENARIO 2: stop, >0 dots founds
            if dots == 0:
                SCENARIO = change_scenario(3)
            elif dots == 1:
                SCENARIO = change_scenario(6)
            elif dots == 2:
                SCENARIO = change_scenario(10)
            else:
                SCENARIO = change_scenario(6)

        elif SCENARIO == 3:
        # SCENARIO 3: turning left half, no dots found
            if dots > 0:
                SCENARIO = change_scenario(4)

        elif SCENARIO == 4:
        # SCENARIO 4: stop, >0 dots found
            if dots == 0:
                SCENARIO = change_scenario(5)
            elif dots == 1:
                SCENARIO = change_scenario(6)
            elif dots == 2:
                SCENARIO = change_scenario(10)
        
        elif SCENARIO == 5:
        # SCENARIO 5: turning right half, no dots found
            if dots > 0:
                SCENARIO = change_scenario(2)

        elif SCENARIO == 6:
        # SCENARIO 6: turning left quater, 1 dot found
            if dots == 0:
                SCENARIO = change_scenario(11)
            elif dots == 2:
                SCENARIO = change_scenario(10)


        elif SCENARIO == 7:
        # SCENARIO 7: stop, >1 dots found
            if dots == 0:
                SCENARIO = change_scenario(1)
            elif dots == 1:
                SCENARIO = change_scenario(8)
            elif dots == 2:
                SCENARIO = change_scenario(10)

        elif SCENARIO == 8:
        # SCENARIO 8: turning right quater, 1 dot found
            if dots == 0:
                SCENARIO = change_scenario(1)
            elif dots == 2:
                SCENARIO = change_scenario(9)

        elif SCENARIO == 9:
        # SCENARIO 9: stop, >1 dot found
            if dots == 0:
                SCENARIO = change_scenario(1)
            elif dots == 1:
                SCENARIO = change_scenario(6)
            elif dots == 2:
                SCENARIO = change_scenario(10)

        if SCENARIO == 10:
        # SCENARIO 10: break
            break

        if SCENARIO == 11:
            if dots == 1:
                SCENARIO = change_scenario(8)

 
        l_key = cv2.waitKey(1) & 0xFF
        if l_key == ord("q"):
           break

        g1.rawCapture.truncate(0)
    g1.rawCapture.truncate(0)


def run_master():

    align_compass()
    communication.sync("DOT_DETECT SETUP")
    run = 0
    while (run != "end"):
        run = communication.socket_motors("not use")
        print run


def run():
    communication.sync("PHASE 2 START")

    if (g0.IS_MASTER == "FOLLOWER"):
        run_follower()         

    elif (g0.IS_MASTER == "MASTER"):
        run_master()

    communication.sync("PHASE 2 END\n\n")

