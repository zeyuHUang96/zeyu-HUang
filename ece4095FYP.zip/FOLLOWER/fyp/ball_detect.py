#===================================================================================
#   FUNCTION LIST:
#
#===================================================================================

#===================================================================================
# import the necessary packages
#===================================================================================

from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
from imutils import perspective

#===================================================================================
#   variables for laser_detction.py
#===================================================================================

import global_variable as g0
import laser_globals as g2
import communication

#===================================================================================
#   functions
#===================================================================================

def PID(error):

    g2.error_sum = g2.error_sum + error
    motorspeed = g2.Kp_ball*(error) + g2.Kd_ball*(error - g2.error_prev) + g2.Ki*(g2.error_sum)
    if (motorspeed < 15):
        motorspeed = 15
    g2.error_prev = error
	
    rightMotorSpeed = 0 - motorspeed
    leftMotorSpeed = 0 + motorspeed 
    
    if (rightMotorSpeed > 100):
        rightMotorSpeed = 100
    elif (rightMotorSpeed < -100):
        rightMotorSpeed = -100
    if (leftMotorSpeed > 100):
        leftMotorSpeed = 100
    elif (leftMotorSpeed < -100):
        leftMotorSpeed = -100

    left = int(leftMotorSpeed)
    right = int(rightMotorSpeed)
    print("PID calculated speed; left: "+str(left)+"     right: "+str(right))
    if (g0.SERIAL_ON):
		communication.serial_motors(left, right)
        
def capture(l_frame, size):

    cv2.setUseOptimized(True)
        
    ## start of main processing
    img2 = l_frame.array
    rotmatrix = cv2.getRotationMatrix2D((size[0]/2,size[1]/2), 270, 1)
    img = cv2.warpAffine(img2, rotmatrix, (size[0], size[1]))
    #img = cv2.resize(img, (340, 220))#resizing image for faster processing
    imgHSV = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)#convert to hsv format


    frame_threshed = cv2.inRange(imgHSV, g2.lowerBound, g2.upperBound)
    cv2.imwrite("HSV.png",frame_threshed)   
    conts = cv2.findContours(frame_threshed.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        
    conts = conts[0]
    number = 0
    
    for c in conts:
		
	if (cv2.contourArea(c) > 8):
		number = number + 1
	else:
		continue
		
	box = cv2.minAreaRect(c)
	box = cv2.cv.BoxPoints(box)
	box = np.array(box, dtype = "int")
	box = perspective.order_points(box)
		
	max_x = int(max(box[0][0],box[1][0],box[2][0],box[3][0]) + 10)
        if max_x > size[1]:
            max_x = size[1]
        min_x = int(min(box[0][0],box[1][0],box[2][0],box[3][0]) - 10)
        if min_x < 0:
            min_x = 0
        max_y = int(max(box[0][1],box[1][1],box[2][1],box[3][1]) + 10)
        if max_y > size[0]:
            max_y = size[0]
        min_y = int(min(box[0][1],box[1][1],box[2][1],box[3][1]) - 10)
        if min_y < 0:
            min_y = 0
            
        box_vals = frame_threshed[min_y:max_y, min_x:max_x]
		
		# Calculate the x centroid
        sum_x = box_vals.sum(axis=0);
        x_vals = np.arange(len(sum_x))
        xi = sum_x*x_vals
        sum_xi = np.sum(xi)
        sum_i = np.sum(sum_x)
        rel_centroid_x = sum_xi/sum_i
        xcoords = range(min_x,max_x+1)
        centroid_x = xcoords[rel_centroid_x]
        #xcoords = range(int(min_x),int(max_x)+1)
        #centroid_x = xcoords[int(rel_centroid_x)]

        # Calculate the y centroid
        sum_y = box_vals.sum(axis=1);
        y_vals = np.arange(len(sum_y))
        yi = sum_y*y_vals #y*i
        sum_yi = np.sum(yi)
        rel_centroid_y = sum_yi/sum_i
        ycoords = range(min_y,max_y+1)
        centroid_y = ycoords[rel_centroid_y]
        #ycoords = range(int(min_y),int(max_y)+1)
        #centroid_y = ycoords[int(rel_centroid_y)]
    
            
	cv2.drawContours(img,[c],-1,(0,255,0),2)
	cv2.circle(img, (centroid_x, centroid_y), 4, (255, 0, 0), 1)
	cv2.putText(img, "center", (centroid_x - 20, centroid_y - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    
    for i in range(len(conts)):
        x,y,w,h=cv2.boundingRect(conts[i])
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255), 2)
        #cv2.PutText(cv2.fromarray(img), str(i+1),(x,y+h), g2.font,(0,255,255))
    if (g0.DEBUGGER_ON):    
        cv2.imshow("cam",img)
        cv2.imshow("thresh",frame_threshed)
    cv2.waitKey(10)

    if (g0.PRINT_ON):
        g0.end = time.time()
        print("Time taken: "+ str(g0.end - g0.start))
        g0.start = g0.end
        
	if (number > 0):
		error = size[0]/2 - centroid_x
	else:
		error = 0
	return error, number

    
    
def start_camera(size):

    try:
        g2.camera = PiCamera()
        g2.camera.resolution = size
    
        #g2.camera.framerate = 90
        
        g2.camera.exposure_mode = "off"
        #g2.camera.awb_mode = "off"
        #g2.camera.awb_gains = [0.9,0]
        #g2.camera.brightness = 50
        #g2.camera.saturation = 100
        #g2.camera.contrast = 0
        
        g2.rawCapture = PiRGBArray(g2.camera, size)
        print("Camera initialised for ball detection")
        time.sleep(0.1)
    except:
        print("Error: could not initialise camera for ball detection")

def close_camera():
    g2.camera.close()
    del g2.camera

def ball_detect():
    
    

    if (g0.IS_MASTER == "FOLLOWER"):

        communication.sync("BALL_DETECT START")

        size = (1088, 1088)
        colour = "blue"
        communication.camera("UP")
        start_camera(size)  # starts the camera

        if (colour == "red"):   # not currently using this.
            g2.lowerBound = np.array([0, 2, 9])
            g2.upperBound = np.array([23,255,255])
        elif (colour == "blue"):
            g2.lowerBound = np.array([105, 40, 40])
            g2.upperBound = np.array([125,255,255])

        communication.sync("BALL_DETECT INITIALISED")

        g0.start = time.time()

        for l_frame in g2.camera.capture_continuous(g2.rawCapture, format="bgr", use_video_port=True):
            print("\n\n")
            error, number = capture(l_frame, size)
            print("number of contours: "+str(number))
            print("calculated error: "+str(error))
            if (number == 1):
                PID(error)
                if (abs(error) < 3):
                    communication.serial_motors(0,0)
                    break
                else:
                    communication.serial_motors(30,-30)


            # don't get rid of any of this stuff
            l_key = cv2.waitKey(1) & 0xFF

            if l_key == ord("q"):
                g2.rawCapture.truncate(0)
                break

            g2.rawCapture.truncate(0)

        close_camera()

        communication.sync("BALL_DETECT END")


    elif (g0.IS_MASTER == "MASTER"):

        communication.sync("BALL_DETECT START")
        communication.LED(1, "blue")
        communication.sync("BALL_DETECT INITIALISED")
        communication.sync("BALL_DETECT END")
        communication.LED(0, "blue")
    
    
    
def ball_detect_inf():
    
    

    if (g0.IS_MASTER == "FOLLOWER"):

        communication.sync("BALL_DETECT START")

        size = (1088, 1088)
        colour = "blue"
        communication.camera("UP")
        start_camera(size)  # starts the camera

        communication.sync("BALL_DETECT INITIALISED")

        g0.start = time.time()

	colour_counter = 0
	
	communication.colour(colour)

        for l_frame in g2.camera.capture_continuous(g2.rawCapture, format="bgr", use_video_port=True):
            print("\n\n")
            if colour_counter > 10:
				colour_counter = 0
	    
				if colour == "blue":
					colour = "red"
					communication.colour("blue")
				else:
					colour = "blue"
					communication.colour("red")
             
	    print colour_counter     
	    print colour
        
	    if (colour == "red"):
			g2.lowerBound = np.array([0, 100, 80])
			g2.upperBound = np.array([30,255,255])
	    elif (colour == "blue"):
				g2.lowerBound = np.array([100, 100, 80])
				g2.upperBound = np.array([130,255,255])
            
            error, number = capture(l_frame, size)
            print("number of contours: "+str(number))
            print("calculated error: "+str(error))
            if (number == 1):
                PID(error)
                if (abs(error) < 3):
                    communication.serial_motors(0,0)
                    communicaiton.colour("end")
                    #break
                    
                else:
                    communication.serial_motors(30,-30)


            # don't get rid of any of this stuff
            l_key = cv2.waitKey(1) & 0xFF

            if l_key == ord("q"):
                g2.rawCapture.truncate(0)
                break

            g2.rawCapture.truncate(0)
            
            colour_counter = colour_counter + 1

        close_camera()

        communication.sync("BALL_DETECT END")


    elif (g0.IS_MASTER == "MASTER"):

        communication.sync("BALL_DETECT START")
        
        run = 0
        while (not run == "end"):
			run = communication.colour("garbage")
			print run
		
        communication.sync("BALL_DETECT INITIALISED")
        communication.sync("BALL_DETECT END")
            


