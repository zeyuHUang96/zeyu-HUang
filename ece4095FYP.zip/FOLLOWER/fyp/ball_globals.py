# import the necessary packages
import numpy as np


Kp = 0.3
Kd = 0.0
Ki = 0.0

error_sum = 0.0
error_prev = 0.0

camera_ball = 0
RawCapture_ball = 0

dots = 0
dot_prev = 0

image = float(0.0)
thresh = 0
