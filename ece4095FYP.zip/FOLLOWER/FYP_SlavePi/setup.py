# import the necessary packages
import serial
import os
import getopt
import sys
import socket
from socket import error as socket_error

#from functions import PID, capture, write_data, draw_lines, send_result
import global_variable as g0
import laser_globals as g1


def set_ser():
	g0.ser = serial.Serial(
	    port='/dev/ttyACM0',
	    baudrate = 57600,
	    parity=serial.PARITY_NONE,
	    stopbits=serial.STOPBITS_ONE,
	    bytesize=serial.EIGHTBITS,
	    timeout=1)


def set_socket():
	g0.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def set_log():
	g0.file = open("/home/pi/github/FYP_SlavePi/data.csv","w").close()      
	g0.file = open("/home/pi/github/FYP_SlavePi/data.csv","a")


def setup_master():
	if (g0.LOGGER_ON):
		set_log()
	if (g0.SERIAL_ON):
		set_ser()
	if (g0.SOCKET_ON):
		set_socket()


def setup_follower():
	if (g0.LOGGER_ON):
		set_log()
	if (g0.SERIAL_ON):
		set_ser()
	if (g0.SOCKET_ON):
		set_socket()
