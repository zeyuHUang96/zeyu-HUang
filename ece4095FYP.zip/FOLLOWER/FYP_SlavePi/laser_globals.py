# import the necessary packages
from scipy.spatial import distance as dist
from picamera.array import PiRGBArray
from picamera import PiCamera
from imutils import perspective
from imutils import contours
import time
import cv2
import imutils
import numpy as np
import math
import serial
import os
import getopt
import sys
from socket import *
from socket import error as socket_error

e_angle = 0.0
e_angle_sum = 0.0
e_angle_prev = 0.0

c_angle = 0.0
t_angle = 0.0

c = 0.0
m = 0.0

xdiff = 0
ydiff = 0

orth_dist = 0.0

leftMotorSpeed = 0.0
rightMotorSpeed = 0.0

Kp = 20
Kd = 10
Ki = 0

dr_mm = 200            # distance for dog-rabbit to aim for along line (mm)
axle_pos = -160
pixpermm = 4
dr = dr_mm * pixpermm

laserdot = np.array([[0,0],[0,0]])
backdot = [0,0]
frontdot = [0,0]
validdots = False

# Coordinate system
xzero = 320
yzero = 200

# Debug lines
axle_line = np.array([[xzero + axle_pos , 0],[xzero + axle_pos, 480]])
centre_line_x = np.array([[xzero, 0],[xzero, 480]])
centre_line_y = np.array([[0, yzero],[640, yzero]])

# allow camera to warm up
cXs = [0, 0]
cYs = [0, 0]

dots_prev = 0

centroid_x_prev = 0
centroid_y_prev = 0

rotmatrix = 0

ser = 0
file = 0

camera = 0
RawCapture = 0

dots = 0
dot_prev = 0

image = float(0.0)
thresh = 0

time_1 = 0
time_2 = 0
time_3 = 0
time_4 = 0
time_6 = 0
time_7 = 0

# BALL DETECT GLOBALs


Kp_ball = 1.0
Kd_ball = 0.0
Ki_ball = 0.0

error_sum = 0.0
error_prev = 0.0
retry=0



