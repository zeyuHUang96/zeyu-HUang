#===================================================================================
#
#	LOCATION TO STORE BASIC GLOBAL VARIABLES
#
#===================================================================================

# what we are testing
DEBUGGER_ON = False
LOGGER_ON = False
SERIAL_ON = False
PRINT_ON = False
SOCKET_ON = False
IS_Master = False

# socket communication globals
sock = 0
port = 12346
client_host = '0.0.0.0'
follower_host = '192.168.43.165'
master_host = '192.168.43.247'

# logging globals
file = 0
ser = 0

# Clock times
end = 0
start = 0

